const state = {
  panelWindowId: null,
  targetTabId: null,
  running: false,
  usernames: [],
  comments: 0,
  scrolls: 0,
  status: "Ready",
  message: "Paste an Instagram Reel URL to begin.",
  logs: [],
  stable: 0,
  lastCount: 0,
  lastHeartbeat: 0,
  connection: "idle"
};

function log(msg) {
  const t = new Date().toLocaleTimeString();
  state.logs.push(`[${t}] ${msg}`);
  if (state.logs.length > 500) state.logs.shift();
  chrome.storage.local.set({collectorState: state});
}

function broadcast() {
  chrome.runtime.sendMessage({type:"STATE", state}).catch(()=>{});
}

function setState(patch) {
  Object.assign(state, patch);
  chrome.storage.local.set({collectorState: state});
  broadcast();
}

async function openPanel() {
  if (state.panelWindowId !== null) {
    try {
      const w = await chrome.windows.get(state.panelWindowId);
      if (w) {
        await chrome.windows.update(state.panelWindowId, {focused:true});
        return;
      }
    } catch (_) {}
    state.panelWindowId = null;
  }

  const w = await chrome.windows.create({
    url: chrome.runtime.getURL("panel.html"),
    type: "popup",
    width: 420,
    height: 720,
    focused: true
  });
  state.panelWindowId = w.id;
  await chrome.storage.local.set({collectorState: state});
}

async function wait(ms) { return new Promise(r => setTimeout(r, ms)); }

async function sendToTab(tabId, message) {
  for (let i=0;i<15;i++) {
    try {
      return await chrome.tabs.sendMessage(tabId, message);
    } catch (e) {
      await wait(500);
    }
  }
  throw new Error("Could not connect to Instagram page. The page may still be loading or Instagram blocked the content script.");
}

async function startCollection(url) {
  if (state.running) return;

  state.running = true;
  state.usernames = [];
  state.comments = 0;
  state.scrolls = 0;
  state.status = "Starting";
  state.message = "Opening the Reel in a background tab...";
  state.logs = [];
  state.stable = 0;
  state.lastCount = 0;
  log("START requested.");
  log("No Instagram login action will be performed.");
  log("Using the existing Kiwi/Instagram session.");
  state.lastHeartbeat = 0;
  state.connection = "connecting";

  try {
    const parsed = new URL(url);
    if (parsed.hostname !== "www.instagram.com" && parsed.hostname !== "instagram.com") {
      throw new Error("This is not an Instagram URL.");
    }

    const tab = await chrome.tabs.create({url, active:false});
    state.targetTabId = tab.id;
    setState({message:"Reel opened. Waiting for Instagram to load..."});
    log(`Target tab created: ${tab.id}`);

    let ready = false;
    for (let i=0;i<40;i++) {
      try {
        const t = await chrome.tabs.get(tab.id);
        if (t.status === "complete") { ready = true; break; }
      } catch (_) { break; }
      await wait(750);
    }
    if (!ready) log("Page did not report complete, attempting connection anyway.");

    setState({status:"Connecting", message:"Connecting to the Instagram Reel..."});
    const result = await sendToTab(tab.id, {type:"COLLECT_START"});
    if (!result || !result.ok) throw new Error(result?.error || "Collector could not start.");

    setState({
      status:"Collecting",
      message:"Reading comments and loading more comments..."
    });
    log("Content script connected successfully.");
    log("Background mode: active. The Instagram tab may stay hidden while collection runs.");
    log("Android/Kiwi can still suspend a hidden tab; heartbeat monitoring will detect that.");
    state.lastHeartbeat = Date.now();
    state.connection = "connected";
    await chrome.storage.local.set({collectorState: state});
    log("Comment collection started.");


    for (let round=1; round<=5000 && state.running; round++) {
      const r = await sendToTab(tab.id, {type:"COLLECT_STEP"});
      state.lastHeartbeat = Date.now();
      state.connection = "connected";
      const names = Array.isArray(r?.usernames) ? r.usernames : [];
      const unique = [...new Set(names)];

      state.usernames = unique;
      state.comments = Number(r?.comments || 0);
      state.scrolls = Number(r?.scrolls || round);
      state.status = "Collecting";
      state.message = r?.message || `Scanning comments... ${unique.length} usernames found.`;
      log(`Step ${round}: ${unique.length} unique usernames, ${state.comments} comment records, scroll ${state.scrolls}.`);
      if (r?.detail) log(r.detail);
      await chrome.storage.local.set({collectorState: state});
      broadcast();

      if (unique.length === state.lastCount) state.stable++; else state.stable = 0;
      state.lastCount = unique.length;

      if (r?.finished) {
        log("Collector reported completion after reaching the end of the comment surface.");
        break;
      }
      // Keep the service worker loop lightweight. The content script owns the
      // adaptive scrolling delay so large collections are not prematurely cut off.
      await wait(150);
    }

    if (state.running) {
      state.running = false;
      state.status = "Finished";
      state.message = `${state.usernames.length} unique usernames collected.`;
      log(`FINISHED. ${state.usernames.length} unique usernames.`);
    }
  } catch (e) {
    state.running = false;
    state.status = "Failed";
    state.message = e?.message || String(e);
    log(`ERROR: ${state.message}`);
  }

  await chrome.storage.local.set({collectorState: state});
  broadcast();
}

chrome.action.onClicked.addListener(() => openPanel());

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === "OPEN_PANEL") {
    openPanel();
    sendResponse({ok:true});
    return true;
  }

  if (msg.type === "START") {
    startCollection(msg.url);
    sendResponse({ok:true});
    return true;
  }

  if (msg.type === "STOP") {
    state.running = false;
    state.status = "Stopped";
    state.message = "Collection stopped by user.";
    log("STOP requested by user.");
    chrome.storage.local.set({collectorState: state});
    broadcast();
    sendResponse({ok:true});
    return true;
  }

  if (msg.type === "GET_STATE") {
    chrome.storage.local.get("collectorState").then(x => {
      if (x.collectorState) Object.assign(state, x.collectorState);
      sendResponse({state});
    });
    return true;
  }

  if (msg.type === "HEARTBEAT") {
    state.lastHeartbeat = Date.now();
    state.connection = "connected";
    if (state.running && state.status === "Paused") {
      state.status = "Collecting";
      state.message = "Instagram tab is responding again. Collection resumed.";
      log("Heartbeat restored: Instagram content script is responding again.");
    }
    chrome.storage.local.set({collectorState: state});
    sendResponse({ok:true});
    return true;
  }

  if (msg.type === "CONTENT_LOG") {
    log(msg.message || "");
    sendResponse({ok:true});
    return true;
  }

  if (msg.type === "CONTENT_STATE") {
    if (msg.patch) Object.assign(state, msg.patch);
    chrome.storage.local.set({collectorState: state});
    broadcast();
    sendResponse({ok:true});
    return true;
  }
});

setInterval(async () => {
  if (!state.running || !state.targetTabId || !state.lastHeartbeat) return;
  const age = Date.now() - state.lastHeartbeat;
  if (age > 12000 && state.connection !== "suspected_pause") {
    state.connection = "suspected_pause";
    state.status = "Paused";
    state.message = "No response from the Instagram tab for a few seconds. It may be suspended in the background; return to Kiwi to wake it.";
    log(`WARNING: Instagram tab heartbeat missing for ${Math.round(age/1000)}s. The tab may be background-suspended.`);
    await chrome.storage.local.set({collectorState: state});
    broadcast();
  }
}, 5000);

chrome.windows.onRemoved.addListener(id => {
  if (id === state.panelWindowId) state.panelWindowId = null;
});
