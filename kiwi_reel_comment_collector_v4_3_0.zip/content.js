(() => {
  if (window.__reelCommentCollectorV4_2) return;
  window.__reelCommentCollectorV4_2 = true;

  const sleep = ms => new Promise(r => setTimeout(r, ms));

  let heartbeatTimer = null;
  function heartbeat() {
    try {
      chrome.runtime.sendMessage({
        type:"HEARTBEAT",
        hidden: document.visibilityState === "hidden",
        url: location.href
      }).catch(()=>{});
    } catch(_) {}
  }
  function startHeartbeat() {
    if (heartbeatTimer) return;
    heartbeat();
    heartbeatTimer = setInterval(heartbeat, 3000);
    document.addEventListener("visibilitychange", heartbeat, {passive:true});
  }
  const found = new Set();
  let initialized = false;
  let scrollCount = 0;
  let bottomPasses = 0;
  let noGrowthPasses = 0;
  let lastScrollTop = -1;
  let lastScrollHeight = -1;
  let scroller = null;

  // Optimized for very large virtualized Instagram comment threads.
  // The previous version repeatedly walked every span/div in the dialog. That
  // becomes extremely expensive as Instagram's comment surface grows.
  const MAX_SCROLL_ROUNDS = 20000;
  const BOTTOM_RETRY_LIMIT = 18;
  const HARD_NO_GROWTH_LIMIT = 80;
  const STEP_WAIT = 550;
  const BOTTOM_WAIT = 1600;

  const RESERVED = new Set([
    "reel","reels","p","explore","accounts","direct","stories","about",
    "web","challenge","privacy","terms","legal","instagram","comments",
    "comment","reply","replies","like","likes","follow","following",
    "more","share","save","send","translate","view","all","previous",
    "load","see"
  ]);

  function sendLog(message) {
    chrome.runtime.sendMessage({type:"CONTENT_LOG", message}).catch(()=>{});
  }

  function usernameFromHref(href) {
    try {
      const u = new URL(href, location.origin);
      if (u.origin !== location.origin) return null;
      const parts = u.pathname.split("/").filter(Boolean);
      if (parts.length !== 1) return null;
      const name = decodeURIComponent(parts[0]).trim();
      if (!name || name.length > 50) return null;
      if (RESERVED.has(name.toLowerCase())) return null;
      if (!/^[A-Za-z0-9._]+$/.test(name)) return null;
      return name;
    } catch (_) { return null; }
  }

  function isVisible(el) {
    const r = el.getBoundingClientRect();
    if (r.width <= 0 || r.height <= 0) return false;
    const s = getComputedStyle(el);
    return s.display !== "none" && s.visibility !== "hidden";
  }

  function getCommentRoots() {
    const dialogs = [...document.querySelectorAll('[role="dialog"]')].filter(isVisible);
    if (dialogs.length) {
      dialogs.sort((a,b) => {
        const ar=a.getBoundingClientRect(), br=b.getBoundingClientRect();
        return (br.width*br.height) - (ar.width*ar.height);
      });
      return [dialogs[0]];
    }
    const mains = [...document.querySelectorAll('main')].filter(isVisible);
    return mains.length ? [mains[0]] : [];
  }

  function clickCommentControl() {
    const els = document.querySelectorAll('button,[role="button"],a');
    for (const el of els) {
      if (!isVisible(el)) continue;
      const label = ((el.getAttribute("aria-label")||"") + " " + (el.textContent||"")).trim().toLowerCase();
      if (["comment","comments","view all comments"].some(w => label === w || label.includes(w))) {
        try { el.click(); sendLog(`Clicked comment control: ${label.slice(0,100)}`); return true; } catch (_) {}
      }
    }
    return false;
  }

  function collect() {
    const roots = getCommentRoots();
    let links = 0, added = 0;
    for (const root of roots) {
      // IMPORTANT: only inspect anchors. Instagram profile links are the stable
      // identifier; scanning every span/div made large threads progressively slow.
      const anchors = root.querySelectorAll('a[href]');
      links += anchors.length;
      for (const a of anchors) {
        const n = usernameFromHref(a.getAttribute("href"));
        if (n && !found.has(n)) { found.add(n); added++; }
      }
    }
    return {added, roots:roots.length, links};
  }

  function findScrollable() {
    if (scroller && scroller.isConnected && isVisible(scroller) && scroller.scrollHeight > scroller.clientHeight + 80) {
      return scroller;
    }
    const roots = getCommentRoots();
    let best = null, bestScore = -Infinity;
    // Search ancestors/nearby containers only. Cache the result afterwards.
    for (const root of roots) {
      const rootRect = root.getBoundingClientRect();
      const candidates = [root, ...root.querySelectorAll('div[style*="overflow"],div[role="presentation"],section,ul,ol')];
      for (const el of candidates) {
        if (!isVisible(el)) continue;
        const sh=el.scrollHeight, ch=el.clientHeight;
        if (sh <= ch + 100 || ch < 180) continue;
        const s=getComputedStyle(el);
        const oy=s.overflowY;
        if (oy !== "auto" && oy !== "scroll" && sh <= ch + 500) continue;
        const r=el.getBoundingClientRect();
        const area=Math.max(1,r.width*r.height);
        // Prefer the visible container closest to the comment dialog size.
        const overlap=Math.max(0, Math.min(r.bottom,rootRect.bottom)-Math.max(r.top,rootRect.top));
        const score=overlap*10 + Math.min(1500, sh-ch) + area/2000;
        if(score>bestScore){best=el;bestScore=score;}
      }
    }
    scroller=best;
    return best;
  }

  function clickMoreButtons() {
    let clicked=0;
    const buttons=document.querySelectorAll('button,[role="button"],a');
    const patterns=["view more comments","load more comments","view previous comments","load previous comments","more comments","see more comments"];
    for(const b of buttons){
      if(!isVisible(b)) continue;
      const t=((b.getAttribute("aria-label")||"")+" "+(b.textContent||"")).trim().toLowerCase();
      if(!t || t.includes("reply")) continue;
      if(patterns.some(p=>t===p || t.includes(p))){try{b.click();clicked++;}catch(_) {}}
    }
    return clicked;
  }

  async function start() {
    if(initialized) return {ok:true};
    initialized=true;
    startHeartbeat();
    sendLog(`Page URL: ${location.href}`);
    await sleep(1200);
    clickCommentControl();
    await sleep(1500);
    sendLog(`Comment surface detected: ${getCommentRoots().length}`);
    scroller=findScrollable();
    if(scroller) sendLog(`Comment scroller found: clientHeight=${Math.round(scroller.clientHeight)}, scrollHeight=${Math.round(scroller.scrollHeight)}`);
    return {ok:true};
  }

  async function step() {
    const before=found.size;
    let more=clickMoreButtons();
    if(more) await sleep(500);
    const info1=collect();

    const el=findScrollable();
    let oldTop=el ? el.scrollTop : window.scrollY;
    let oldHeight=el ? el.scrollHeight : document.documentElement.scrollHeight;
    let max=el ? Math.max(0,el.scrollHeight-el.clientHeight) : Math.max(0,document.documentElement.scrollHeight-window.innerHeight);
    let amount=el ? Math.max(650, Math.min(el.clientHeight*0.90, 1400)) : Math.max(650, window.innerHeight*0.90);
    let target=Math.min(max,oldTop+amount);

    if(el && target>oldTop+1) {
      el.scrollTop=target;
      try { el.dispatchEvent(new WheelEvent("wheel",{bubbles:true,cancelable:true,deltaY:amount,deltaMode:0})); } catch(_) {}
    } else if(!el) {
      window.scrollBy(0,amount);
    }
    scrollCount++;

    const moved=el ? el.scrollTop>oldTop+1 : window.scrollY>oldTop+1;
    let wait=STEP_WAIT;
    if(el && el.scrollTop >= Math.max(0,el.scrollHeight-el.clientHeight-20)) wait=BOTTOM_WAIT;
    await sleep(wait);

    more+=clickMoreButtons();
    const info2=collect();
    const after=found.size;

    const nowEl=findScrollable() || el;
    const top=nowEl ? Math.round(nowEl.scrollTop) : Math.round(window.scrollY);
    const height=nowEl ? Math.round(nowEl.scrollHeight) : Math.round(document.documentElement.scrollHeight);
    const nowMax=nowEl ? Math.max(0,nowEl.scrollHeight-nowEl.clientHeight) : Math.max(0,document.documentElement.scrollHeight-window.innerHeight);
    const atBottom=top>=nowMax-20;
    const geometryChanged=top!==lastScrollTop || height!==lastScrollHeight;
    const added=after-before;

    if(added>0 || geometryChanged || !atBottom) bottomPasses=0;
    else if(atBottom) bottomPasses++;
    noGrowthPasses=added===0 ? noGrowthPasses+1 : 0;
    lastScrollTop=top;
    lastScrollHeight=height;

    const detail=`Scan: +${added} users, links ${info1.links+info2.links}, more-clicks ${more}, moved=${moved}, bottom=${atBottom}, bottomPasses=${bottomPasses}, noGrowth=${noGrowthPasses}, scrollTop=${top}, scrollHeight=${height}`;

    // A bottom pass only counts when BOTH geometry and usernames remain unchanged.
    // This avoids ending while Instagram is asynchronously appending another batch.
    const finished=scrollCount>=MAX_SCROLL_ROUNDS ||
      (atBottom && bottomPasses>=BOTTOM_RETRY_LIMIT && noGrowthPasses>=20);

    return {ok:true,usernames:[...found],comments:after,scrolls:scrollCount,message:`${after.toLocaleString()} unique usernames found · ${scrollCount.toLocaleString()} scan rounds`,detail,finished};
  }

  chrome.runtime.onMessage.addListener((msg,sender,sendResponse)=>{
    if(msg.type==="COLLECT_START"){start().then(sendResponse).catch(e=>sendResponse({ok:false,error:e.message}));return true;}
    if(msg.type==="COLLECT_STEP"){step().then(sendResponse).catch(e=>sendResponse({ok:false,error:e.message}));return true;}
  });
})();
