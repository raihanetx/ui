const $ = id => document.getElementById(id);
let currentState = null;

function render(s){
  currentState = s;
  $("status").textContent = s.status || "Ready";
  $("message").dataset.connection = s.connection || "idle";
  $("message").textContent = s.message || "";
  $("users").textContent = (s.usernames||[]).length;
  $("comments").textContent = s.comments || 0;
  $("scrolls").textContent = s.scrolls || 0;
  $("start").disabled = !!s.running;
  $("stop").disabled = !s.running;
  const d=$("dot");
  d.className="dot " + (s.running ? "work" : (s.status==="Failed" ? "fail" : "ok"));
  $("log").textContent = (s.logs||[]).join("\\n") || "Waiting...";
  $("log").scrollTop = $("log").scrollHeight;
  $("copyUsers").disabled = !(s.usernames||[]).length;
}

function load(){
  chrome.runtime.sendMessage({type:"GET_STATE"}, r=>{
    if(r?.state) render(r.state);
  });
}
chrome.runtime.onMessage.addListener(msg=>{
  if(msg.type==="STATE" && msg.state) render(msg.state);
});

$("start").onclick=()=>{
  const url=$("url").value.trim();
  if(!url){ $("message").textContent="Paste an Instagram Reel URL first."; return; }
  chrome.runtime.sendMessage({type:"START",url});
};
$("stop").onclick=()=>chrome.runtime.sendMessage({type:"STOP"});
$("copyUsers").onclick=()=>{
  const text=(currentState?.usernames||[]).join("\\n");
  navigator.clipboard.writeText(text);
};
$("copyLog").onclick=()=>{
  navigator.clipboard.writeText((currentState?.logs||[]).join("\\n"));
};
$("clearLog").onclick=()=>{
  chrome.storage.local.get("collectorState").then(x=>{
    const s=x.collectorState || {};
    s.logs=[];
    chrome.storage.local.set({collectorState:s});
    render(s);
  });
};
load();
