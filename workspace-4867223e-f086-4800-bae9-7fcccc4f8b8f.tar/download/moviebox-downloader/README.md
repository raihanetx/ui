# MovieBox Downloader (Material 3)

A local web app that downloads movies & dramas from themoviebox.xyz.

Paste a MovieBox link → it shows the cover, title, details, seasons,
episodes, dub languages, video qualities and subtitles → you pick what
you want → click Download → the file saves through your browser like a
normal download.

## Features

- Auto-detects content type: Movie, multi-part movie, or TV series with seasons
- Shows cover photo, title, year, country, genres, IMDb rating, cast, description
- Dub/audio language switcher (Hindi, English, Arabic, French, ...)
- Quality picker (360p / 480p / 720p / 1080p) with file sizes
- Subtitle downloads (SRT) in every language the title offers
- Batch download: tick multiple episodes or a whole season
- Download history with one-tap re-download
- No login needed — the app uses the site's guest access
- Android-style Material 3 (Material You) design, light & dark

## Requirements

- Python 3.9+
- ~10 MB of pip packages

## Setup

```bash
cd moviebox-downloader
pip install -r requirements.txt
python app.py
```

Then open **http://localhost:8000** in your browser.

## How to use

1. Copy any title link from themoviebox.xyz
   (e.g. `themoviebox.xyz/detail/teach-you-a-lesson-hindi-eFztro3UVh5?...`)
2. Paste it into the small search bar and press **Go**
   — or just type a name to search MovieBox
3. Pick the **audio/dub language** chips if other languages exist
4. Pick the **season** (for series), the **quality** and the **subtitles**
5. Tick the episodes you want (or **Select all**) → press **Download**
   — or press the round download button on a single episode
6. Files land in your browser's normal download folder

## Notes

- Downloads run through your browser's download manager
  (pause/resume works like any normal browser download).
- If a batch is large, downloads start one by one with a small delay
  so the CDN does not rate-limit you.
- Use for personal viewing only — the content is copyrighted.
- If the site changes its API someday, the endpoints live at the top of
  `app.py` and are easy to update.
