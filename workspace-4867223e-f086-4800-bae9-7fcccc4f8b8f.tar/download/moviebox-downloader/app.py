#!/usr/bin/env python3
"""
MovieBox Downloader — local web app (Material 3 style)
Scrapes themoviebox.xyz metadata (title, cover, seasons, episodes, dubs,
qualities, subtitles) and streams video downloads through your browser.

Run:   python app.py        then open  http://localhost:8000
Needs: pip install flask requests
"""

import re
import time
import uuid
from urllib.parse import quote, urlparse, parse_qs

import requests
from flask import Flask, Response, jsonify, request, send_from_directory

# ----------------------------------------------------------------------------
# Configuration
# ----------------------------------------------------------------------------
API_BASE = "https://h5-api.aoneroom.com/wefeed-h5api-bff"
PLAY_BASE = "https://themoviebox.xyz/wefeed-h5api-bff"
SITE_ORIGIN = "https://themoviebox.xyz"
PORT = 8000

MOBILE_UA = ("Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 "
             "(KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36")

app = Flask(__name__, static_folder="static", static_url_path="/static")


# ----------------------------------------------------------------------------
# Guest token handling (no login required by the site)
# ----------------------------------------------------------------------------
class TokenManager:
    """Fetches and caches the anonymous guest token issued by the API."""

    def __init__(self):
        self._token = None
        self._expiry = 0.0

    def get(self):
        if self._token and time.time() < self._expiry - 3600:
            return self._token
        try:
            r = requests.get(
                f"{API_BASE}/country-code",
                headers={
                    "User-Agent": MOBILE_UA,
                    "Origin": SITE_ORIGIN,
                    "Referer": f"{SITE_ORIGIN}/",
                },
                timeout=20,
            )
            token = r.cookies.get("token")
            if not token:
                # try set-cookie header manually
                sc = r.headers.get("set-cookie", "")
                m = re.search(r"token=([^;]+)", sc)
                if m:
                    token = m.group(1)
            if not token:
                raise RuntimeError("no guest token issued")
            self._token = token
            self._expiry = time.time() + 6 * 24 * 3600  # refresh daily-ish
            return token
        except Exception as e:
            if self._token:
                return self._token  # fall back to old token
            raise RuntimeError(f"failed to get guest token: {e}")


tokens = TokenManager()


def api_headers(bearer=True, referer=None, json_body=False):
    h = {
        "User-Agent": MOBILE_UA,
        "Origin": SITE_ORIGIN,
        "Referer": referer or f"{SITE_ORIGIN}/",
        "x-request-lang": "en",
    }
    if json_body:
        h["Content-Type"] = "application/json"
    if bearer:
        h["authorization"] = f"Bearer {tokens.get()}"
    return h


# ----------------------------------------------------------------------------
# Helpers
# ----------------------------------------------------------------------------
def slug_from_url(url: str):
    """Extract the detailPath slug from any moviebox URL form."""
    if not url:
        return None
    url = url.strip()
    if not url.startswith("http"):
        # allow pasting just the slug
        if re.fullmatch(r"[A-Za-z0-9_-]{4,}", url):
            return url
        url = "https://" + url.lstrip("/")
    try:
        p = urlparse(url)
        host = (p.hostname or "").lower()
        if "moviebox" not in host and "aoneroom" not in host and p.path:
            # not the right site, maybe user pasted something else
            pass
        m = re.search(r"/(?:detail|movies|video)/(?:([^/]+)/)?([A-Za-z0-9_-]+)", p.path)
        if m:
            # skip locale prefix like /hi/detail/...
            seg = m.group(2)
            return seg
        # query fallback: ?id=..&type=/movie/detail
        qs = parse_qs(p.query)
        if "id" in qs:
            return None
    except Exception:
        pass
    return None


def fmt_size(num):
    try:
        num = int(num)
    except (TypeError, ValueError):
        return ""
    for unit in ["B", "KB", "MB", "GB"]:
        if num < 1024 or unit == "GB":
            return f"{num:.1f} {unit}" if unit != "B" else f"{num} B"
        num /= 1024
    return f"{num:.1f} GB"


def fmt_duration(sec):
    try:
        sec = int(sec)
    except (TypeError, ValueError):
        return ""
    if sec <= 0:
        return ""
    h, m = sec // 3600, (sec % 3600) // 60
    return f"{h}h {m:02d}m" if h else f"{m}m"


def normalize_detail(data: dict) -> dict:
    """Convert the raw detail API payload into a clean UI-friendly dict."""
    subj = data.get("subject") or {}
    resource = data.get("resource") or {}
    stars = data.get("stars") or []

    stype = subj.get("subjectType")
    type_name = {1: "movie", 2: "series", 6: "video"}.get(stype, "video")

    seasons_raw = resource.get("seasons") or []
    seasons = []
    for s in seasons_raw:
        resolutions = []
        for r in (s.get("resolutions") or []):
            if r.get("resolution"):
                resolutions.append(int(r["resolution"]))
        seasons.append({
            "se": s.get("se", 0),
            "maxEp": s.get("maxEp", 0),
            "resolutions": sorted(set(resolutions)),
        })

    # Content layout decision:
    #  - series: seasons with episodes (se>=1, maxEp>=1)
    #  - movie with single part: one card (se==0, maxEp==0)
    #  - movie with multiple parts: each season entry = a part
    is_movie_style = type_name == "movie"
    if is_movie_style and seasons:
        max_eps = [s["maxEp"] for s in seasons]
        if all(m == 0 for m in max_eps):
            # multi-part movie: expose parts
            parts = []
            for s in seasons:
                label = ("Movie" if len(seasons) == 1
                         else f"Part {s['se']}" if s["se"] else "Movie")
                parts.append({"se": s["se"], "ep": 0, "label": label,
                              "resolutions": s["resolutions"]})
            content = {"layout": "parts", "items": parts}
        else:
            content = {"layout": "parts", "items": [
                {"se": 0, "ep": 0, "label": "Movie",
                 "resolutions": sorted({r for s in seasons for r in s["resolutions"]})}
            ]}
    elif seasons:
        episodes_layout = []
        for s in seasons:
            eps = s["maxEp"] if s["maxEp"] and s["maxEp"] > 0 else 1
            episodes_layout.append({"se": s["se"], "maxEp": eps,
                                    "label": f"Season {s['se']}",
                                    "resolutions": s["resolutions"]})
        content = {"layout": "episodes", "seasons": episodes_layout}
    else:
        content = {"layout": "parts", "items": [
            {"se": 0, "ep": 0, "label": type_name.title(),
             "resolutions": []}]}

    dubs = []
    for d in (subj.get("dubs") or []):
        dubs.append({
            "lanName": d.get("lanName", ""),
            "lanCode": d.get("lanCode", ""),
            "detailPath": d.get("detailPath", ""),
            "original": bool(d.get("original")),
            "current": d.get("detailPath") == subj.get("detailPath"),
        })
    if not dubs:
        dubs = [{"lanName": "Original", "detailPath": subj.get("detailPath", ""),
                 "original": True, "current": True, "lanCode": ""}]

    subs = [x.strip() for x in str(subj.get("subtitles") or "").split(",") if x.strip()]

    cast = []
    for s in stars[:12]:
        cast.append({
            "name": s.get("name", ""),
            "character": s.get("character", ""),
            "avatar": s.get("avatarUrl") or "",
        })

    genre = [g.strip() for g in str(subj.get("genre") or "").split(",") if g.strip()]

    return {
        "subjectId": str(subj.get("subjectId") or ""),
        "detailPath": subj.get("detailPath", ""),
        "type": type_name,
        "title": subj.get("title", ""),
        "description": subj.get("description", ""),
        "cover": (subj.get("cover") or {}).get("url", ""),
        "releaseDate": subj.get("releaseDate", ""),
        "year": str(subj.get("releaseDate") or "")[:4],
        "duration": fmt_duration(subj.get("duration")),
        "durationSeconds": subj.get("duration") or 0,
        "genres": genre,
        "country": subj.get("countryName", ""),
        "imdb": str(subj.get("imdbRatingValue") or ""),
        "source": resource.get("source", ""),
        "dubs": dubs,
        "subtitles": subs,
        "cast": cast,
        "content": content,
        "hasResource": bool(subj.get("hasResource")) or bool(seasons_raw),
    }


# ----------------------------------------------------------------------------
# API routes
# ----------------------------------------------------------------------------
@app.get("/")
def index():
    return send_from_directory("static", "index.html")


@app.post("/api/resolve")
def api_resolve():
    """Paste a moviebox URL (or bare slug) -> full metadata."""
    body = request.get_json(silent=True) or {}
    url = (body.get("url") or "").strip()
    slug = slug_from_url(url)
    if not slug:
        return jsonify({"ok": False,
                        "error": "Please paste a MovieBox link "
                                 "(themoviebox.xyz/detail/...) or search by name."}), 400
    try:
        r = requests.get(
            f"{API_BASE}/detail",
            params={"detailPath": slug},
            headers=api_headers(bearer=False),
            timeout=25)
        d = r.json()
    except Exception as e:
        return jsonify({"ok": False, "error": f"Network error: {e}"}), 502

    if d.get("code") != 0 or not d.get("data"):
        return jsonify({"ok": False, "error": "Not found on MovieBox. "
                        "Check the link and try again."}), 404

    # isForbid / access checks
    data = d["data"]
    if data.get("isForbid"):
        return jsonify({"ok": False, "error": "This title is blocked/restricted."}), 403

    out = normalize_detail(data)
    out["ok"] = True
    return jsonify(out)


@app.route("/api/detail/<path:slug>", methods=["GET", "POST"])
def api_detail(slug):
    """Fetch detail for another dub language (or reload)."""
    try:
        r = requests.get(
            f"{API_BASE}/detail",
            params={"detailPath": slug},
            headers=api_headers(bearer=False),
            timeout=25)
        d = r.json()
    except Exception as e:
        return jsonify({"ok": False, "error": f"Network error: {e}"}), 502
    if d.get("code") != 0 or not d.get("data"):
        return jsonify({"ok": False, "error": "Not found."}), 404
    out = normalize_detail(d["data"])
    out["ok"] = True
    return jsonify(out)


@app.post("/api/links")
def api_links():
    """Get downloadable stream links + subtitles for one episode/movie."""
    body = request.get_json(silent=True) or {}
    detail_path = body.get("detailPath") or ""
    subject_id = str(body.get("subjectId") or "")
    se = body.get("se", 0)
    ep = body.get("ep", 0)
    referer = f"{SITE_ORIGIN}/movies/{detail_path}"

    if not detail_path or not subject_id:
        return jsonify({"ok": False, "error": "missing detailPath/subjectId"}), 400

    try:
        r = requests.get(
            f"{PLAY_BASE}/subject/play",
            params={
                "subjectId": subject_id,
                "se": se,
                "ep": ep,
                "detailPath": detail_path,
                "streamSignType": 1,
                "supportCodecs[h264]": 1,
            },
            headers=api_headers(bearer=True, referer=referer),
            timeout=30)
        d = r.json()
    except Exception as e:
        return jsonify({"ok": False, "error": f"Network error: {e}"}), 502

    if d.get("code") != 0:
        msg = d.get("message") or "play API error"
        return jsonify({"ok": False, "error": msg}), 502

    data = d.get("data") or {}
    streams = []
    for s in (data.get("streams") or []):
        if s.get("vipLocked") or not s.get("url"):
            continue  # hide VIP-locked / empty streams
        streams.append({
            "format": s.get("format", "MP4"),
            "id": s.get("id", ""),
            "url": s.get("url", ""),
            "resolution": str(s.get("resolutions", "")),
            "size": fmt_size(s.get("size")),
            "sizeBytes": int(s.get("size") or 0),
            "duration": fmt_duration(s.get("duration")),
        })
    streams.sort(key=lambda x: int(x["resolution"] or 0))

    # Subtitles: use the first available stream id
    captions = []
    if streams:
        try:
            rc = requests.get(
                f"{API_BASE}/subject/caption",
                params={
                    "format": "MP4",
                    "id": streams[0]["id"],
                    "subjectId": subject_id,
                    "detailPath": detail_path,
                },
                headers=api_headers(bearer=True, referer=referer),
                timeout=20)
            cd = rc.json()
            for c in (cd.get("data") or {}).get("captions") or []:
                captions.append({
                    "lanName": c.get("lanName", ""),
                    "lan": c.get("lan", ""),
                    "url": c.get("url", ""),
                    "size": fmt_size(c.get("size")),
                })
        except Exception:
            pass  # subtitles optional

    if not streams:
        return jsonify({
            "ok": False,
            "error": "No downloadable streams (VIP-only or not uploaded yet).",
            "streams": [], "captions": [],
        }), 404

    return jsonify({"ok": True, "streams": streams, "captions": captions})


@app.post("/api/search")
def api_search():
    """Search MovieBox by keyword."""
    body = request.get_json(silent=True) or {}
    keyword = (body.get("q") or "").strip()
    if not keyword:
        return jsonify({"ok": False, "error": "empty query"}), 400
    try:
        r = requests.post(
            f"{API_BASE}/subject/search",
            json={"keyword": keyword, "page": body.get("page", 1),
                  "perPage": body.get("perPage", 24)},
            headers=api_headers(bearer=True, json_body=True),
            timeout=25)
        d = r.json()
    except Exception as e:
        return jsonify({"ok": False, "error": f"Network error: {e}"}), 502

    items = []
    for i in (d.get("data") or {}).get("items") or []:
        cover = (i.get("cover") or {}).get("url", "") if isinstance(i.get("cover"), dict) else i.get("coverUrl", "")
        items.append({
            "title": i.get("title", ""),
            "detailPath": i.get("detailPath", ""),
            "type": {1: "movie", 2: "series", 6: "video"}.get(i.get("subjectType"), "video"),
            "cover": cover or "",
            "year": str(i.get("releaseDate") or "")[:4],
            "hasResource": bool(i.get("hasResource")),
        })
    return jsonify({"ok": True, "items": items})


@app.get("/api/download")
def api_download():
    """Stream-proxy a CDN file so the browser downloads it natively."""
    url = request.args.get("url") or ""
    filename = request.args.get("filename") or "download.mp4"
    if not url.startswith("https://"):
        return jsonify({"ok": False, "error": "bad url"}), 400
    if "hakunaymatata.com" not in url and "aoneroom.com" not in url:
        return jsonify({"ok": False, "error": "unsupported host"}), 400

    fwd_headers = {
        "User-Agent": MOBILE_UA,
        "Referer": f"{SITE_ORIGIN}/",
    }
    rng = request.headers.get("Range")
    if rng:
        fwd_headers["Range"] = rng

    try:
        upstream = requests.get(url, headers=fwd_headers, stream=True, timeout=30)
    except Exception as e:
        return jsonify({"ok": False, "error": f"upstream error: {e}"}), 502

    if upstream.status_code in (429, 403):
        upstream.close()
        return jsonify({"ok": False, "error": "CDN refused (rate limited) - "
                        "wait a few seconds and retry."}), 429

    safe_name = re.sub(r"[^\w.\- ()\[\]]+", "_", filename).strip() or "download.mp4"

    def generate():
        try:
            for chunk in upstream.iter_content(chunk_size=1024 * 256):
                if chunk:
                    yield chunk
        finally:
            upstream.close()

    resp_headers = {
        "Content-Disposition": f"attachment; filename*=UTF-8''{quote(safe_name)}",
        "Cache-Control": "no-store",
    }
    for h in ("Content-Length", "Content-Type", "Content-Range", "Accept-Ranges", "ETag"):
        v = upstream.headers.get(h)
        if v:
            resp_headers[h] = v
    if "Content-Type" not in resp_headers:
        resp_headers["Content-Type"] = "application/octet-stream"

    return Response(generate(), status=upstream.status_code, headers=resp_headers)


# ----------------------------------------------------------------------------
# Run
# ----------------------------------------------------------------------------
if __name__ == "__main__":
    print("=" * 62)
    print("  MovieBox Downloader — Material 3")
    print(f"  Open in your browser:  http://localhost:{PORT}")
    print("  (Ctrl+C to stop)")
    print("=" * 62)
    app.run(host="0.0.0.0", port=PORT, threaded=True)
