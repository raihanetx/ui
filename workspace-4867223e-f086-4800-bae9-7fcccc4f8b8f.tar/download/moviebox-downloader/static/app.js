/* ============================================================
   MovieBox Downloader — frontend logic (Material 3)
   ============================================================ */
"use strict";

/* ---------- state ---------- */
const state = {
  detail: null,          // current normalized detail object
  currentDub: null,      // selected dub detailPath
  currentSe: null,       // selected season (number)
  selectedQuality: null, // e.g. "720"
  selectedSubs: new Set(), // subtitle lanNames to include
  selectedEps: new Set(),  // "se:ep" keys
  linksCache: new Map(),   // key "se:ep" -> links response
  dlHistory: [],           // download history
};

const $ = (id) => document.getElementById(id);
const screens = { home: $("screenHome"), detail: $("screenDetail"), downloads: $("screenDownloads") };

/* ---------- helpers ---------- */
function showSnackbar(msg, ms = 3200) {
  const sb = $("snackbar");
  $("snackbarText").textContent = msg;
  sb.classList.add("show");
  clearTimeout(showSnackbar._t);
  showSnackbar._t = setTimeout(() => sb.classList.remove("show"), ms);
}

function setLoading(on, msg) {
  const el = $("homeLoading");
  el.classList.toggle("hidden", !on);
  if (msg) el.querySelector("span").textContent = msg;
}

async function api(path, body) {
  const opts = body
    ? { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) }
    : {};
  const r = await fetch(path, opts);
  const d = await r.json().catch(() => ({ ok: false, error: "Bad server response" }));
  if (!r.ok && d && d.error) throw new Error(d.error);
  if (d && d.ok === false && d.error) throw new Error(d.error);
  return d;
}

function epKey(se, ep) { return `${se}:${ep}`; }

function safeName(title) {
  return (title || "video").replace(/[\\/:*?"<>|]+/g, "").replace(/\s+/g, " ").trim().slice(0, 80);
}

function pad2(n) { return String(n).padStart(2, "0"); }

/* ripple effect for Android feel */
document.addEventListener("pointerdown", (e) => {
  const host = e.target.closest(".m3-chip, .btn-filled, .btn-tonal, .btn-text, .ep-dl, .result-card, .ep-card, .nav-item, .icon-btn");
  if (!host) return;
  const rect = host.getBoundingClientRect();
  const ink = document.createElement("span");
  ink.className = "ripple-ink";
  const size = Math.max(rect.width, rect.height);
  ink.style.width = ink.style.height = size + "px";
  ink.style.left = (e.clientX - rect.left - size / 2) + "px";
  ink.style.top = (e.clientY - rect.top - size / 2) + "px";
  if (getComputedStyle(host).position === "static") host.style.position = "relative";
  host.appendChild(ink);
  setTimeout(() => ink.remove(), 600);
});

/* ---------- navigation ---------- */
function navigate(screen) {
  Object.values(screens).forEach((s) => s.classList.add("hidden"));
  screens[screen].classList.remove("hidden");
  const detailView = screen === "detail";
  $("btnBack").classList.toggle("hidden", !detailView);
  $("topTitle").classList.toggle("hidden", !detailView);
  document.querySelectorAll(".nav-item").forEach((n) =>
    n.classList.toggle("active", n.dataset.nav === (screen === "detail" ? "home" : screen))
  );
  const tb = $("topBar");
  if (screen === "detail") {
    tb.classList.add("elevated");
    $("topTitle").textContent = state.detail ? state.detail.title : "";
  } else {
    tb.classList.remove("elevated");
  }
  if (screen !== "detail") $("batchBar").classList.add("hidden");
}

$("btnBack").addEventListener("click", () => navigate("home"));
document.querySelectorAll(".nav-item").forEach((n) =>
  n.addEventListener("click", () => navigate(n.dataset.nav))
);

/* ---------- search / resolve ---------- */
async function handleSearch() {
  const q = $("searchInput").value.trim();
  if (!q) return showSnackbar("Paste a MovieBox link or type a name first");
  $("homeError").classList.add("hidden");
  $("resultsSection").classList.add("hidden");

  const isUrl = /^(https?:\/\/|www\.|[a-z0-9-]+\.[a-z]{2,})/i.test(q) || /^[\w-]{15,}$/.test(q);
  if (isUrl) {
    setLoading(true, "Resolving link…");
    try {
      const d = await api("/api/resolve", { url: q });
      setLoading(false);
      if (d.ok) renderDetail(d);
    } catch (err) {
      setLoading(false);
      showHomeError(err.message);
    }
  } else {
    setLoading(true, "Searching…");
    try {
      const d = await api("/api/search", { q });
      setLoading(false);
      renderResults(d.items || []);
    } catch (err) {
      setLoading(false);
      showHomeError(err.message);
    }
  }
}

function showHomeError(msg) {
  const el = $("homeError");
  el.textContent = msg;
  el.classList.remove("hidden");
}

$("btnSearch").addEventListener("click", handleSearch);
$("searchInput").addEventListener("keydown", (e) => { if (e.key === "Enter") handleSearch(); });
$("btnClear").addEventListener("click", () => {
  $("searchInput").value = "";
  $("btnClear").classList.add("hidden");
  $("searchInput").focus();
});
$("searchInput").addEventListener("input", () => {
  $("btnClear").classList.toggle("hidden", !$("searchInput").value);
});
$("btnPaste").addEventListener("click", async () => {
  try {
    const text = await navigator.clipboard.readText();
    if (text) { $("searchInput").value = text.trim(); $("btnClear").classList.remove("hidden"); }
  } catch { showSnackbar("Clipboard not available — long-press to paste"); }
});

/* ---------- search results ---------- */
function renderResults(items) {
  const grid = $("resultGrid");
  grid.innerHTML = "";
  if (!items.length) {
    $("resultsSection").classList.remove("hidden");
    grid.innerHTML = '<div class="no-res">No results found — try another name</div>';
    return;
  }
  for (const it of items) {
    const card = document.createElement("div");
    card.className = "result-card";
    card.innerHTML = `
      <img src="${it.cover || ""}" alt="" loading="lazy"
           onerror="this.style.visibility='hidden'">
      <div class="result-info">
        <div class="result-title">${escapeHtml(it.title)}</div>
        <div class="result-meta">
          <span class="tag-badge ${it.type}">${it.type}</span>
          ${it.year ? `<span class="result-year">${it.year}</span>` : ""}
          ${!it.hasResource ? '<span class="result-year">· no download</span>' : ""}
        </div>
      </div>`;
    card.addEventListener("click", () => openDetail(it.detailPath));
    grid.appendChild(card);
  }
  $("resultsSection").classList.remove("hidden");
}

async function openDetail(slug) {
  setLoading(true, "Loading…");
  try {
    const d = await api(`/api/detail/${encodeURIComponent(slug)}`);
    setLoading(false);
    if (d.ok) renderDetail(d);
  } catch (err) {
    setLoading(false);
    showHomeError(err.message);
  }
}

function escapeHtml(s) {
  return String(s || "").replace(/[&<>"']/g, (c) =>
    ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
}

/* ---------- detail rendering ---------- */
function renderDetail(d) {
  state.detail = d;
  state.currentDub = d.detailPath;
  state.currentSe = null;
  state.selectedEps = new Set();
  state.linksCache = new Map();
  state.selectedQuality = null;
  state.selectedSubs = new Set();

  navigate("detail");
  screens.detail.scrollTop = 0;

  /* hero */
  $("heroCover").src = d.cover || "";
  $("badgeType").textContent = d.type === "series" ? "TV Series" : d.type === "movie" ? "Movie" : "Video";
  $("detailTitle").textContent = d.title;
  $("topTitle").textContent = d.title;

  const meta = [];
  if (d.year) meta.push(`<span class="meta-chip"><span class="material-symbols-rounded">calendar_month</span>${d.year}</span>`);
  if (d.country) meta.push(`<span class="meta-chip"><span class="material-symbols-rounded">public</span>${escapeHtml(d.country)}</span>`);
  if (d.duration) meta.push(`<span class="meta-chip"><span class="material-symbols-rounded">schedule</span>${d.duration}</span>`);
  if (d.imdb && d.imdb !== "0") meta.push(`<span class="meta-chip"><span class="material-symbols-rounded star fill">star</span>IMDb ${d.imdb}</span>`);
  (d.genres || []).slice(0, 3).forEach((g) =>
    meta.push(`<span class="meta-chip">${escapeHtml(g)}</span>`));
  $("metaRow").innerHTML = meta.join("");

  /* description + cast */
  $("detailDesc").textContent = d.description || "No description available.";
  const castRow = $("castRow");
  castRow.innerHTML = "";
  if ((d.cast || []).length) {
    castRow.classList.remove("hidden");
    for (const c of d.cast.slice(0, 10)) {
      const pill = document.createElement("div");
      pill.className = "cast-pill";
      pill.innerHTML = `${c.avatar ? `<img src="${c.avatar}" alt="" loading="lazy" onerror="this.style.display='none'">` : ""}
        <span class="cast-name">${escapeHtml(c.name)}</span>`;
      castRow.appendChild(pill);
    }
  } else castRow.classList.add("hidden");
  $("descCard").classList.remove("hidden");

  /* dubs */
  const dubBlock = $("dubBlock");
  const dubChips = $("dubChips");
  dubChips.innerHTML = "";
  if ((d.dubs || []).length > 1) {
    dubBlock.classList.remove("hidden");
    for (const dub of d.dubs) {
      const chip = document.createElement("button");
      chip.className = "m3-chip" + (dub.current ? " selected" : "");
      chip.innerHTML = `<span class="material-symbols-rounded">${dub.original ? "graphic_eq" : "translate"}</span>${escapeHtml(dub.lanName)}`;
      if (dub.current) chip.disabled = true;
      else chip.addEventListener("click", () => switchDub(dub.detailPath, dub.lanName));
      dubChips.appendChild(chip);
    }
  } else dubBlock.classList.add("hidden");

  /* content list */
  const content = d.content || {};
  if (content.layout === "episodes") {
    $("seasonBlock").classList.remove("hidden");
    $("listTitle").textContent = "Episodes";
    const seasons = content.seasons;
    // pick default season: first
    const se = seasons[0].se;
    renderSeasonChips(seasons, se);
    renderSeason(se);
  } else {
    $("seasonBlock").classList.add("hidden");
    $("listTitle").textContent = "Movie";
    renderParts(content.items || []);
  }
  $("listSection").classList.remove("hidden");
  $("detailLoading").classList.add("hidden");
  $("detailError").classList.add("hidden");

  updateBatchBar();
}

async function switchDub(detailPath, lanName) {
  showSnackbar(`Switching to ${lanName}…`);
  try {
    const d = await api(`/api/detail/${encodeURIComponent(detailPath)}`);
    if (d.ok) { renderDetail(d); showSnackbar(`Now showing: ${d.title}`); }
  } catch (err) {
    showSnackbar(err.message);
  }
}

function renderSeasonChips(seasons, activeSe) {
  const row = $("seasonChips");
  row.innerHTML = "";
  for (const s of seasons) {
    const chip = document.createElement("button");
    chip.className = "m3-chip" + (s.se === activeSe ? " selected" : "");
    chip.innerHTML = `<span class="material-symbols-rounded">tv</span>${escapeHtml(s.label.replace("Season ", "S"))}`;
    chip.addEventListener("click", () => {
      if (state.currentSe === s.se) return;
      renderSeasonChips(seasons, s.se);
      renderSeason(s.se);
    });
    row.appendChild(chip);
  }
}

function renderSeason(se) {
  state.currentSe = se;
  state.selectedEps = new Set();
  $("btnSelectAll").classList.remove("hidden");
  const content = state.detail.content;
  const season = content.seasons.find((s) => s.se === se) || content.seasons[0];
  const eps = season.maxEp || 1;
  const list = $("epList");
  list.innerHTML = "";

  for (let ep = 1; ep <= eps; ep++) {
    const card = document.createElement("div");
    card.className = "ep-card";
    card.dataset.se = se; card.dataset.ep = ep;
    card.innerHTML = `
      <div class="ep-check"><span class="material-symbols-rounded">check</span></div>
      <div class="ep-info">
        <div class="ep-name">Episode ${ep}</div>
        <div class="ep-sub">S${pad2(se)} · EP${pad2(ep)} · tap to select</div>
      </div>
      <button class="ep-dl" title="Download this episode"><span class="material-symbols-rounded">download</span></button>`;
    card.addEventListener("click", (e) => {
      if (e.target.closest(".ep-dl")) return;
      toggleEpisode(card, se, ep);
    });
    card.querySelector(".ep-dl").addEventListener("click", () => {
      downloadOne(se, ep, card.querySelector(".ep-dl"));
    });
    list.appendChild(card);
  }
  updateBatchBar();
  // prefetch links for first episode to populate quality + subtitle chips
  prefetchLinks(se, 1);
}

function renderParts(parts) {
  state.currentSe = parts[0] ? parts[0].se : 0;
  const list = $("epList");
  list.innerHTML = "";
  // single movie — no need for bulk controls
  $("btnSelectAll").classList.toggle("hidden", parts.length < 2);
  for (const p of parts) {
    const card = document.createElement("div");
    card.className = "ep-card";
    card.dataset.se = p.se; card.dataset.ep = p.ep;
    card.innerHTML = `
      <div class="ep-check"><span class="material-symbols-rounded">check</span></div>
      <div class="ep-info">
        <div class="ep-name">${escapeHtml(p.label)}</div>
        <div class="ep-sub">${p.resolutions.length ? p.resolutions.map((r) => r + "p").join(" · ") : "tap download to see sizes"}</div>
      </div>
      <button class="ep-dl" title="Download"><span class="material-symbols-rounded">download</span></button>`;
    card.addEventListener("click", (e) => {
      if (e.target.closest(".ep-dl")) return;
      toggleEpisode(card, p.se, p.ep);
    });
    card.querySelector(".ep-dl").addEventListener("click", () => {
      downloadOne(p.se, p.ep, card.querySelector(".ep-dl"));
    });
    list.appendChild(card);
  }
  updateBatchBar();
  prefetchLinks(parts[0].se, parts[0].ep);
}

function toggleEpisode(card, se, ep) {
  const key = epKey(se, ep);
  if (state.selectedEps.has(key)) {
    state.selectedEps.delete(key);
    card.classList.remove("selected");
  } else {
    state.selectedEps.add(key);
    card.classList.add("selected");
  }
  updateBatchBar();
}

$("btnSelectAll").addEventListener("click", () => {
  const cards = document.querySelectorAll(".ep-card");
  const allSelected = cards.length && state.selectedEps.size === cards.length;
  cards.forEach((c) => {
    const key = epKey(c.dataset.se, c.dataset.ep);
    if (allSelected) { state.selectedEps.delete(key); c.classList.remove("selected"); }
    else { state.selectedEps.add(key); c.classList.add("selected"); }
  });
  updateBatchBar();
});

function updateBatchBar() {
  const bar = $("batchBar");
  const n = state.selectedEps.size;
  if (!n) { bar.classList.add("hidden"); return; }
  bar.classList.remove("hidden");
  $("batchCount").textContent = `${n} selected`;
  // estimate size from cache if possible
  let bytes = 0, known = 0;
  for (const key of state.selectedEps) {
    const links = state.linksCache.get(key);
    if (links) {
      const st = pickStream(links);
      if (st) { bytes += st.sizeBytes; known++; }
    }
  }
  $("batchSize").textContent = known
    ? `~${fmtBytes(bytes)} total (estimated${known < n ? ", loading…" : ""})`
    : "";
}

function fmtBytes(n) {
  if (!n) return "0 B";
  const u = ["B", "KB", "MB", "GB"];
  let i = 0;
  while (n >= 1024 && i < 3) { n /= 1024; i++; }
  return `${n.toFixed(i ? 1 : 0)} ${u[i]}`;
}

/* ---------- links fetching ---------- */
async function prefetchLinks(se, ep) {
  try {
    const links = await getLinks(se, ep);
    renderQualityChips(links);
    renderSubtitleChips(links);
  } catch { /* ignore prefetch failures */ }
}

async function getLinks(se, ep) {
  const key = epKey(se, ep);
  if (state.linksCache.has(key)) return state.linksCache.get(key);
  const d = await api("/api/links", {
    detailPath: state.detail.detailPath,
    subjectId: state.detail.subjectId,
    se: Number(se), ep: Number(ep),
  });
  if (!d.streams || !d.streams.length) throw new Error("No downloadable streams for this item");
  const links = { streams: d.streams, captions: d.captions || [] };
  state.linksCache.set(key, links);
  updateBatchBar();
  return links;
}

function renderQualityChips(links) {
  const block = $("qualityBlock");
  const row = $("qualityChips");
  const quals = links.streams.map((s) => s.resolution);
  if (!quals.length) { block.classList.add("hidden"); return; }
  block.classList.remove("hidden");
  row.innerHTML = "";
  // default: highest quality
  if (!state.selectedQuality || !quals.includes(state.selectedQuality)) {
    state.selectedQuality = quals[quals.length - 1];
  }
  for (const q of quals) {
    const st = links.streams.find((s) => s.resolution === q);
    const chip = document.createElement("button");
    chip.className = "m3-chip" + (q === state.selectedQuality ? " selected" : "");
    chip.innerHTML = `<span class="material-symbols-rounded">high_quality</span>${q}p · ${st.size}`;
    chip.addEventListener("click", () => {
      state.selectedQuality = q;
      row.querySelectorAll(".m3-chip").forEach((c) => c.classList.remove("selected"));
      chip.classList.add("selected");
      updateBatchBar();
    });
    row.appendChild(chip);
  }
}

function renderSubtitleChips(links) {
  const block = document.createElement("div");
  block.className = "chip-block hidden";
  block.id = "subsBlock";
  block.innerHTML = `<h3 class="chip-title"><span class="material-symbols-rounded">subtitles</span> Subtitles (saved with video)</h3>
    <div class="chip-row" id="subsChips"></div>`;
  const old = $("subsBlock");
  if (old) old.remove();
  const caps = links.captions || [];
  if (!caps.length) return;
  block.classList.remove("hidden");
  const row = block.querySelector("#subsChips");
  for (const c of caps) {
    const chip = document.createElement("button");
    chip.className = "m3-chip" + (state.selectedSubs.has(c.lanName) ? " selected" : "");
    chip.innerHTML = `<span class="material-symbols-rounded">subtitles</span>${escapeHtml(c.lanName)}`;
    chip.addEventListener("click", () => {
      if (state.selectedSubs.has(c.lanName)) {
        state.selectedSubs.delete(c.lanName);
        chip.classList.remove("selected");
      } else {
        state.selectedSubs.add(c.lanName);
        chip.classList.add("selected");
      }
    });
    row.appendChild(chip);
  }
  $("seasonBlock").parentNode.insertBefore(block, $("qualityBlock"));
}

function pickStream(links) {
  const streams = links.streams;
  if (!streams.length) return null;
  let st = streams.find((s) => s.resolution === state.selectedQuality);
  if (!st) {
    const quals = streams.map((s) => parseInt(s.resolution) || 0);
    const target = parseInt(state.selectedQuality) || 99999;
    let best = 0;
    for (let i = 1; i < streams.length; i++) {
      if (Math.abs(quals[i] - target) < Math.abs(quals[best] - target)) best = i;
    }
    st = streams[best];
  }
  return st;
}

/* ---------- downloads ---------- */
function buildFilename(se, ep, stream, ext = "mp4") {
  const t = safeName(state.detail.title);
  const q = stream ? `${stream.resolution}p` : "";
  if (state.detail.type === "series" && state.detail.content.layout === "episodes") {
    return `${t} - S${pad2(se)}E${pad2(ep)}${q ? " [" + q + "]" : ""}.${ext}`;
  }
  const label = getCurrentLabel(se, ep);
  return `${t}${label !== "Movie" ? " - " + label : ""}${q ? " [" + q + "]" : ""}.${ext}`;
}

function getCurrentLabel(se, ep) {
  const content = state.detail.content;
  if (content.layout === "parts") {
    const p = content.items.find((x) => x.se === Number(se) && x.ep === Number(ep));
    if (p && content.items.length > 1) return p.label;
    return "Movie";
  }
  return `S${pad2(se)}E${pad2(ep)}`;
}

function triggerBrowserDownload(url, filename) {
  const a = document.createElement("a");
  a.href = `/api/download?url=${encodeURIComponent(url)}&filename=${encodeURIComponent(filename)}`;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
}

async function downloadOne(se, ep, btn) {
  if (btn) { btn.disabled = true; btn.querySelector(".material-symbols-rounded").textContent = "hourglass_top"; }
  try {
    // always fetch fresh links (CDN signs expire)
    const key = epKey(se, ep);
    state.linksCache.delete(key);
    const links = await getLinks(se, ep);
    renderQualityChips(links);
    renderSubtitleChips(links);
    const stream = pickStream(links);
    if (!stream) throw new Error("No stream available");
    const fname = buildFilename(se, ep, stream, "mp4");
    triggerBrowserDownload(stream.url, fname);
    recordDownload(fname, stream, se, ep);
    showSnackbar(`Downloading ${fname} — check your browser downloads`, 4000);
    // subtitles
    await downloadSubs(se, ep, links);
  } catch (err) {
    showSnackbar(err.message);
  } finally {
    if (btn) {
      btn.disabled = false;
      btn.querySelector(".material-symbols-rounded").textContent = "download";
    }
  }
}

async function downloadSubs(se, ep, links) {
  if (!state.selectedSubs.size) return;
  const caps = (links.captions || []).filter((c) => state.selectedSubs.has(c.lanName));
  for (const c of caps) {
    const fname = buildFilename(se, ep, null, "srt").replace(/\.srt$/, ` [${c.lanName}].srt`);
    triggerBrowserDownload(c.url, fname);
    await sleep(400);
  }
}

function sleep(ms) { return new Promise((r) => setTimeout(r, ms)); }

$("btnBatch").addEventListener("click", async () => {
  const keys = [...state.selectedEps];
  if (!keys.length) return;
  const btn = $("btnBatch");
  btn.disabled = true;
  let done = 0;
  showSnackbar(`Starting ${keys.length} download${keys.length > 1 ? "s" : ""}… Your browser may ask to allow multiple files.`);
  for (const key of keys) {
    const [se, ep] = key.split(":").map(Number);
    try {
      await downloadOne(se, ep, null);
      done++;
      $("batchCount").textContent = `${done}/${keys.length} started`;
    } catch (err) {
      console.error(err);
    }
    if (done < keys.length) await sleep(1600); // gentle on the CDN
  }
  btn.disabled = false;
  $("batchCount").textContent = `${keys.length} selected`;
  if (done) showSnackbar(`Started ${done} download${done > 1 ? "s" : ""} — watch the browser download bar`);
});

/* ---------- download history ---------- */
function loadHistory() {
  try { state.dlHistory = JSON.parse(localStorage.getItem("mb_dl_history") || "[]"); }
  catch { state.dlHistory = []; }
}

function recordDownload(filename, stream, se, ep) {
  state.dlHistory.unshift({
    filename, size: stream.size, quality: stream.resolution + "p",
    title: state.detail.title, url: stream.url,
    ts: Date.now(), detailPath: state.detail.detailPath,
    subjectId: state.detail.subjectId, se, ep,
  });
  state.dlHistory = state.dlHistory.slice(0, 100);
  localStorage.setItem("mb_dl_history", JSON.stringify(state.dlHistory));
  renderHistory();
}

function renderHistory() {
  const list = $("dlList");
  list.innerHTML = "";
  const items = state.dlHistory;
  $("dlEmpty").classList.toggle("hidden", items.length > 0);
  $("btnClearHistory").classList.toggle("hidden", !items.length);
  for (const it of items) {
    const card = document.createElement("div");
    card.className = "dl-card";
    const when = new Date(it.ts).toLocaleString([], { month: "short", day: "numeric", hour: "2-digit", minute: "2-digit" });
    card.innerHTML = `
      <div class="dl-icon"><span class="material-symbols-rounded">movie</span></div>
      <div class="dl-info">
        <div class="dl-title">${escapeHtml(it.filename)}</div>
        <div class="dl-meta">${escapeHtml(it.quality)} · ${escapeHtml(it.size)} · ${when}</div>
      </div>
      <button class="dl-again" title="Download again"><span class="material-symbols-rounded">refresh</span></button>`;
    card.querySelector(".dl-again").addEventListener("click", async () => {
      try {
        // fetch a fresh signed link before re-downloading
        const d = await api("/api/links", {
          detailPath: it.detailPath, subjectId: it.subjectId, se: it.se, ep: it.ep,
        });
        const st = d.streams.find((s) => s.resolution + "p" === it.quality) || d.streams[0];
        if (!st) throw new Error("No stream");
        triggerBrowserDownload(st.url, it.filename);
        showSnackbar(`Re-downloading ${it.filename}`);
      } catch (err) {
        // fall back to cached url (may be expired)
        if (it.url) {
          triggerBrowserDownload(it.url, it.filename);
          showSnackbar("Using cached link — if it fails, open the title again");
        } else showSnackbar(err.message);
      }
    });
    list.appendChild(card);
  }
}

$("btnClearHistory").addEventListener("click", () => {
  state.dlHistory = [];
  localStorage.removeItem("mb_dl_history");
  renderHistory();
  showSnackbar("History cleared (your files are untouched)");
});

/* ---------- init ---------- */
loadHistory();
renderHistory();
navigate("home");
$("searchInput").focus();
