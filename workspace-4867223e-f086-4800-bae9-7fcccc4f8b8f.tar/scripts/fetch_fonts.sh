#!/bin/bash
# Self-host Material Symbols Rounded + Roboto for the Material 3 UI
set -e
mkdir -p /home/z/my-project/public/fonts
cd /home/z/my-project/public/fonts

UA="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Safari/537.36"

# Material Symbols Rounded (variable font)
CSS_URL="https://fonts.googleapis.com/css2?family=Material+Symbols+Rounded:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200&display=block"
curl -s -A "$UA" "$CSS_URL" -o ms.css
MS_URL=$(grep -oP "https://[^)]+\.woff2" ms.css | head -1)
echo "Material Symbols URL: $MS_URL"
curl -s -A "$UA" "$MS_URL" -o material-symbols-rounded.woff2

# Roboto 400/500/700
for W in 400 500 700; do
  curl -s -A "$UA" "https://fonts.googleapis.com/css2?family=Roboto:wght@$W&display=swap" -o "roboto-$W.css"
  RURL=$(grep -oP "https://[^)]+\.woff2" "roboto-$W.css" | head -1)
  echo "Roboto $W URL: $RURL"
  curl -s -A "$UA" "$RURL" -o "roboto-$W.woff2"
done

rm -f *.css
ls -la
