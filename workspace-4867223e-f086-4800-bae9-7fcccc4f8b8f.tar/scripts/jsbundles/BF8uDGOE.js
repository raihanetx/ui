import{_ as o,x as t,o as c,bE as n}from"./Cc1PKC3O.js";const _={};function r(s,a){const e=n;return c(),t(e)}const f=o(_,[["render",r]]);export{f as default};
