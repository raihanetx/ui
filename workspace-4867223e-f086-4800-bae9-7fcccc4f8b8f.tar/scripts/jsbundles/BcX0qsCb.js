import{aq as e}from"./Cc1PKC3O.js";const a=()=>e("seoTdkMeta",()=>({}));export{a as u};
