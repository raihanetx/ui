#!/usr/bin/env python3
"""Moviebox API client — token exchange + all endpoints"""
import hashlib
import json
import time
import urllib.error
import urllib.parse
import urllib.request

API = "https://h5-api.aoneroom.com"
UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"

_bearer = None


def client_token() -> str:
    ts = int(time.time())
    md5 = hashlib.md5(str(ts)[::-1].encode()).hexdigest()
    return f"{ts},{md5}"


def call(path, method="GET", body=None, params=None, bearer=None):
    global _bearer
    url = API + path
    if params:
        url += "?" + urllib.parse.urlencode(params)
    headers = {
        "User-Agent": UA,
        "Accept": "application/json",
        "Content-Type": "application/json",
        "Origin": "https://themoviebox.xyz",
        "Referer": "https://themoviebox.xyz/",
        "X-Client-Info": json.dumps({"timezone": "Asia/Dhaka"}),
        "X-Request-Lang": "en",
    }
    tok = bearer or _bearer
    if tok:
        headers["Authorization"] = f"Bearer {tok}"
    else:
        headers["X-Client-Token"] = client_token()
    data = json.dumps(body).encode() if body is not None else None
    req = urllib.request.Request(url, data=data, headers=headers, method=method)
    try:
        resp = urllib.request.urlopen(req, timeout=25)
        raw = resp.read().decode()
        # capture issued bearer token (anonymous JWT from x-user header)
        xuser = resp.headers.get("x-user")
        if xuser and not _bearer:
            try:
                _bearer = json.loads(xuser).get("token")
            except Exception:
                pass
        return json.loads(raw)
    except urllib.error.HTTPError as e:
        try:
            return json.loads(e.read().decode())
        except Exception:
            return {"http_error": e.code}


def ensure_token():
    """First contact to obtain anonymous JWT bearer."""
    if _bearer:
        return _bearer
    call("/wefeed-h5api-bff/detail", params={"detailPath": "/detail/teach-you-a-lesson-hindi-eFztro3UVh5"})
    return _bearer


def search(keyword, page=1, per_page=24):
    ensure_token()
    return call("/wefeed-h5api-bff/subject/search", method="POST",
                body={"keyword": keyword, "page": page, "perPage": per_page})


def detail(detail_path, se=None):
    params = {"detailPath": detail_path}
    if se is not None:
        params["se"] = se
    return call("/wefeed-h5api-bff/detail", params=params)


def search_suggest(keyword):
    return call("/wefeed-h5api-bff/subject/search-suggest", method="POST",
                body={"keyword": keyword, "perPage": 10})


if __name__ == "__main__":
    print("bearer:", (ensure_token() or "NONE")[:40], "...")
    print("\n=== SEARCH ===")
    r = search("teach you a lesson")
    print("code:", r.get("code"), "| data keys:", list(r.get("data", {}).keys()))
    items = r.get("data", {}).get("items") or r.get("data", {}).get("subjects") or []
    for it in items[:6]:
        print(" -", it.get("title"), "| type:", it.get("subjectType"), "|", it.get("detailPath"))
