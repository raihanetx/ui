#!/bin/bash
# Browser UI test - fixed click syntax
cd /home/z/my-project/download/moviebox-downloader
pkill -f "python3 app.py" 2>/dev/null; sleep 1
python3 app.py > /tmp/mbserver.log 2>&1 &
SPID=$!
sleep 3

agent-browser close 2>/dev/null
agent-browser set viewport 430 900 > /dev/null 2>&1
agent-browser open "http://localhost:8000" 2>&1 | tail -1
agent-browser wait 2500 > /dev/null 2>&1

# type the URL into search bar and press Enter
agent-browser eval "document.getElementById('searchInput').value='https://themoviebox.xyz/detail/teach-you-a-lesson-hindi-eFztro3UVh5?id=4439270089858372624&type=/movie/detail'; document.getElementById('btnSearch').click(); 'clicked'" 2>&1 | head -1
sleep 7
agent-browser screenshot /home/z/my-project/scripts/ui_2_detail.png 2>&1 | head -1
agent-browser eval "document.getElementById('detailTitle').textContent" 2>&1 | head -1
agent-browser eval "document.querySelectorAll('.ep-card').length + ' episode cards'" 2>&1 | head -1

# scroll to episodes
agent-browser scroll down 800 > /dev/null 2>&1
agent-browser wait 2500 > /dev/null 2>&1
agent-browser screenshot /home/z/my-project/scripts/ui_3_episodes.png 2>&1 | head -1
agent-browser eval "document.querySelectorAll('.m3-chip').length + ' chips total'" 2>&1 | head -1

# select first 3 episodes
agent-browser eval "document.querySelectorAll('.ep-card').forEach((c,i)=>{ if(i<3) c.click(); }); document.querySelectorAll('.ep-card.selected').length + ' selected'" 2>&1 | head -1
agent-browser screenshot /home/z/my-project/scripts/ui_4_batch.png 2>&1 | head -1
agent-browser eval "document.getElementById('batchCount').textContent" 2>&1 | head -1

# search flow test
agent-browser eval "document.getElementById('btnBack').click(); 'back'" > /dev/null 2>&1
agent-browser eval "document.getElementById('searchInput').value='gadar'; document.getElementById('btnSearch').click(); 'searching'" 2>&1 | head -1
sleep 5
agent-browser screenshot /home/z/my-project/scripts/ui_5_search.png 2>&1 | head -1
agent-browser eval "document.querySelectorAll('.result-card').length + ' result cards'" 2>&1 | head -1

# open first result (movie)
agent-browser eval "document.querySelector('.result-card').click(); 'opening movie'" > /dev/null 2>&1
sleep 6
agent-browser screenshot /home/z/my-project/scripts/ui_6_movie.png 2>&1 | head -1
agent-browser eval "document.getElementById('detailTitle').textContent + ' | type: ' + document.getElementById('badgeType').textContent" 2>&1 | head -1

kill $SPID 2>/dev/null
echo "=== BROWSER TEST DONE ==="
