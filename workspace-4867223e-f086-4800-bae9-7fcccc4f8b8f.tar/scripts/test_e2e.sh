#!/bin/bash
# End-to-end test: start server, test APIs, keep alive for browser test
cd /home/z/my-project/download/moviebox-downloader

# kill any old instance
pkill -f "python3 app.py" 2>/dev/null; sleep 1

python3 app.py > /tmp/mbserver.log 2>&1 &
SERVER_PID=$!
sleep 3

echo "=== 1. UI serves ==="
curl -s http://localhost:8000/ -o /dev/null -w "HTTP %{http_code}\n"

echo "=== 2. Resolve (user's example URL) ==="
curl -s -X POST http://localhost:8000/api/resolve -H "Content-Type: application/json" \
  -d '{"url":"https://themoviebox.xyz/detail/teach-you-a-lesson-hindi-eFztro3UVh5?id=4439270089858372624&scene=&page_from=search_detail&type=/movie/detail"}' \
  | python3 -c "
import json,sys
d = json.load(sys.stdin)
print('ok:', d.get('ok'), '| title:', d.get('title'), '| type:', d.get('type'))
print('seasons:', json.dumps(d.get('content',{}).get('seasons')))
print('dubs:', len(d.get('dubs',[])), '| subtitles:', d.get('subtitles'))
"

echo "=== 3. Links (S1E1) ==="
curl -s -X POST http://localhost:8000/api/links -H "Content-Type: application/json" \
  -d '{"detailPath":"teach-you-a-lesson-hindi-eFztro3UVh5","subjectId":"4439270089858372624","se":1,"ep":1}' \
  -o /tmp/links.json
python3 -c "
import json
d = json.load(open('/tmp/links.json'))
print('ok:', d.get('ok'))
for s in d.get('streams',[]): print(' ', s['resolution'],'p |', s['size'], '|', s['url'][:70])
print('captions:', [c['lanName'] for c in d.get('captions',[])])
"

echo "=== 4. Download proxy (range 0-300KB) ==="
DLURL=$(python3 -c "
import json, urllib.parse
d = json.load(open('/tmp/links.json'))
print(urllib.parse.quote(d['streams'][0]['url'], safe=''))
")
curl -s "http://localhost:8000/api/download?url=$DLURL&filename=test%20episode.mp4" \
  -r 0-300000 -o /tmp/dl_test.mp4 -w "HTTP %{http_code} | %{size_download} bytes\n" --max-time 60
file /tmp/dl_test.mp4

echo "=== 5. Search API ==="
curl -s -X POST http://localhost:8000/api/search -H "Content-Type: application/json" \
  -d '{"q":"gadar"}' | python3 -c "
import json,sys
d = json.load(sys.stdin)
print('ok:', d.get('ok'), '| results:', len(d.get('items',[])))
for i in d.get('items',[])[:3]: print(' -', i['title'], '(' + i['type'] + ')')
"

echo "=== 6. Movie resolve (Gadar 2) ==="
curl -s -X POST http://localhost:8000/api/resolve -H "Content-Type: application/json" \
  -d '{"url":"gadar-2-uDUs6fNA127"}' | python3 -c "
import json,sys
d = json.load(sys.stdin)
print('ok:', d.get('ok'), '| title:', d.get('title'), '| type:', d.get('type'))
print('content:', json.dumps(d.get('content')))
"

echo ""
echo "SERVER STILL RUNNING (pid $SERVER_PID) - for browser test"
# keep server alive: wait here so the parent bash keeps the process
wait $SERVER_PID
