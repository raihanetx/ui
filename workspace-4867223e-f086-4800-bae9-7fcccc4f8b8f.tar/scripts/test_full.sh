#!/bin/bash
# Full test: server + APIs + browser UI screenshots
cd /home/z/my-project/download/moviebox-downloader
pkill -f "python3 app.py" 2>/dev/null; sleep 1
python3 app.py > /tmp/mbserver.log 2>&1 &
SPID=$!
sleep 3

echo "=== 1. UI ==="
curl -s http://localhost:8000/ -o /dev/null -w "HTTP %{http_code}\n"

echo "=== 2. Resolve ==="
RES=$(curl -s -X POST http://localhost:8000/api/resolve -H "Content-Type: application/json" \
  -d '{"url":"https://themoviebox.xyz/detail/teach-you-a-lesson-hindi-eFztro3UVh5?id=4439270089858372624&scene=&page_from=search_detail&type=/movie/detail"}')
echo "$RES" | python3 -c "
import json,sys
d = json.load(sys.stdin)
print('ok:', d.get('ok'), '| title:', d.get('title'), '| type:', d.get('type'))
print('seasons:', json.dumps(d.get('content',{}).get('seasons')))
print('dubs:', len(d.get('dubs',[])), 'languages')
"

echo "=== 3. Links S1E1 ==="
curl -s -X POST http://localhost:8000/api/links -H "Content-Type: application/json" \
  -d '{"detailPath":"teach-you-a-lesson-hindi-eFztro3UVh5","subjectId":"4439270089858372624","se":1,"ep":1}' \
  -o /tmp/links.json --max-time 60
python3 -c "
import json
d = json.load(open('/tmp/links.json'))
print('ok:', d.get('ok'))
for s in d.get('streams',[]): print(' ', s['resolution'],'p |', s['size'])
print('captions:', [c['lanName'] for c in d.get('captions',[])])
"

echo "=== 4. Download proxy (300KB range) ==="
DLURL=$(python3 -c "
import json, urllib.parse
d = json.load(open('/tmp/links.json'))
print(urllib.parse.quote(d['streams'][0]['url'], safe=''))
")
curl -s "http://localhost:8000/api/download?url=$DLURL&filename=test%20episode.mp4" \
  -r 0-300000 -o /tmp/dl_test.mp4 -w "HTTP %{http_code} | %{size_download} bytes\n" --max-time 90
file /tmp/dl_test.mp4

echo "=== 5. Search ==="
curl -s -X POST http://localhost:8000/api/search -H "Content-Type: application/json" -d '{"q":"gadar"}' \
  | python3 -c "
import json,sys
d = json.load(sys.stdin)
print('ok:', d.get('ok'), '| results:', len(d.get('items',[])))
for i in d.get('items',[])[:3]: print(' -', i['title'], '(' + i['type'] + ')', i['year'])
"

echo "=== 6. Movie resolve (Gadar 2) ==="
curl -s -X POST http://localhost:8000/api/resolve -H "Content-Type: application/json" \
  -d '{"url":"gadar-2-uDUs6fNA127"}' | python3 -c "
import json,sys
d = json.load(sys.stdin)
print('ok:', d.get('ok'), '| title:', d.get('title'), '| type:', d.get('type'))
print('content:', json.dumps(d.get('content')))
"

echo "=== 7. Browser UI test ==="
agent-browser close 2>/dev/null
agent-browser set viewport 430 900 2>&1 | head -1
agent-browser open "http://localhost:8000" 2>&1 | tail -1
agent-browser wait 2000 > /dev/null 2>&1
agent-browser screenshot /home/z/my-project/scripts/ui_1_home.png 2>&1 | head -1

# paste link and go
agent-browser eval "document.getElementById('searchInput').value='https://themoviebox.xyz/detail/teach-you-a-lesson-hindi-eFztro3UVh5?id=4439270089858372624&type=/movie/detail'" > /dev/null 2>&1
agent-browser click "find role button click --name Go" 2>&1 | head -1 || agent-browser eval "document.getElementById('btnSearch').click()" > /dev/null 2>&1
sleep 6
agent-browser screenshot /home/z/my-project/scripts/ui_2_detail.png 2>&1 | head -1

# scroll to episodes
agent-browser scroll down 700 > /dev/null 2>&1
sleep 2
agent-browser screenshot /home/z/my-project/scripts/ui_3_episodes.png 2>&1 | head -1

# select episodes 1-3
agent-browser eval "
document.querySelectorAll('.ep-card').forEach((c,i)=>{ if(i<3) c.click(); });
'selected: ' + document.querySelectorAll('.ep-card.selected').length
" 2>&1 | head -2
agent-browser screenshot /home/z/my-project/scripts/ui_4_batch.png 2>&1 | head -1

echo "=== 8. UI text sanity ==="
agent-browser eval "document.getElementById('detailTitle').textContent" 2>&1 | head -2
agent-browser eval "document.querySelectorAll('.ep-card').length + ' episodes, ' + document.querySelectorAll('.m3-chip').length + ' chips'" 2>&1 | head -2

kill $SPID 2>/dev/null
echo "=== ALL TESTS DONE ==="
