import { NextRequest, NextResponse } from "next/server";
import { fetchDetail } from "@/lib/moviebox";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET(
  _req: NextRequest,
  ctx: { params: Promise<{ slug: string }> }
) {
  const { slug } = await ctx.params;
  try {
    const decoded = decodeURIComponent(slug);
    const detail = await fetchDetail(decoded);
    return NextResponse.json(detail);
  } catch (e) {
    return NextResponse.json(
      { ok: false, error: e instanceof Error ? e.message : String(e) },
      { status: 404 }
    );
  }
}
