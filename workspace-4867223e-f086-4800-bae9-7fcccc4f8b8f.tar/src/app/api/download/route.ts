import { NextRequest, NextResponse } from "next/server";
import { MOBILE_UA, SITE_ORIGIN } from "@/lib/moviebox";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";
// streaming downloads can be long; disable any buffering/timeout helpers
export const maxDuration = 3600;

const ALLOWED_HOSTS = [
  "hakunaymatata.com",
  "aoneroom.com",
  "themoviebox.xyz",
];

function isAllowedUrl(raw: string): URL | null {
  try {
    const u = new URL(raw);
    if (u.protocol !== "https:") return null;
    const host = u.hostname.toLowerCase();
    if (!ALLOWED_HOSTS.some((h) => host === h || host.endsWith("." + h))) return null;
    return u;
  } catch {
    return null;
  }
}

function safeFilename(name: string): string {
  const cleaned = name.replace(/[^\w.\- ()\[\]]+/g, "_").trim();
  return cleaned || "download.mp4";
}

export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url);
  const url = searchParams.get("url") || "";
  const filename = searchParams.get("filename") || "download.mp4";

  const parsed = isAllowedUrl(url);
  if (!parsed) {
    return NextResponse.json({ ok: false, error: "bad url" }, { status: 400 });
  }

  const fwdHeaders: Record<string, string> = {
    "User-Agent": MOBILE_UA,
    Referer: `${SITE_ORIGIN}/`,
    Accept: "*/*",
  };
  const range = req.headers.get("range");
  if (range) fwdHeaders["Range"] = range;

  let upstream: Response;
  try {
    // NOTE: no AbortSignal timeout — video streams can be large and slow
    upstream = await fetch(parsed.toString(), {
      headers: fwdHeaders,
      redirect: "follow",
    });
  } catch (e) {
    return NextResponse.json(
      { ok: false, error: `upstream error: ${String(e)}` },
      { status: 502 }
    );
  }

  if (upstream.status === 429 || upstream.status === 403) {
    // drain & discard body so the socket is released
    try {
      await upstream.arrayBuffer();
    } catch {
      /* ignore */
    }
    return NextResponse.json(
      {
        ok: false,
        error: "CDN refused (rate limited) — wait a few seconds and retry.",
      },
      { status: 429 }
    );
  }

  if (!upstream.ok && upstream.status !== 206) {
    try {
      await upstream.arrayBuffer();
    } catch {
      /* ignore */
    }
    return NextResponse.json(
      { ok: false, error: `CDN error ${upstream.status}` },
      { status: 502 }
    );
  }

  const safe = safeFilename(filename);
  const headers = new Headers();
  headers.set(
    "Content-Disposition",
    `attachment; filename*=UTF-8''${encodeURIComponent(safe)}`
  );
  headers.set("Cache-Control", "no-store");
  for (const h of [
    "Content-Length",
    "Content-Type",
    "Content-Range",
    "Accept-Ranges",
    "ETag",
    "Last-Modified",
  ]) {
    const v = upstream.headers.get(h);
    if (v) headers.set(h, v);
  }
  if (!headers.has("Content-Type")) {
    headers.set("Content-Type", "application/octet-stream");
  }

  return new Response(upstream.body, {
    status: upstream.status,
    headers,
  });
}
