import { NextRequest, NextResponse } from "next/server";
import { fetchLinks } from "@/lib/moviebox";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function POST(req: NextRequest) {
  let body: {
    detailPath?: string;
    subjectId?: string;
    se?: number;
    ep?: number;
  } = {};
  try {
    body = await req.json();
  } catch {
    /* empty */
  }
  const detailPath = (body.detailPath || "").trim();
  const subjectId = String(body.subjectId || "").trim();
  const se = Number(body.se) || 0;
  const ep = Number(body.ep) || 0;

  if (!detailPath || !subjectId) {
    return NextResponse.json(
      { ok: false, error: "missing detailPath/subjectId" },
      { status: 400 }
    );
  }
  try {
    const { streams, captions } = await fetchLinks(detailPath, subjectId, se, ep);
    if (!streams.length) {
      return NextResponse.json(
        {
          ok: false,
          error: "No downloadable streams (VIP-only or not uploaded yet).",
          streams: [],
          captions: [],
        },
        { status: 404 }
      );
    }
    return NextResponse.json({ ok: true, streams, captions });
  } catch (e) {
    return NextResponse.json(
      { ok: false, error: e instanceof Error ? e.message : String(e) },
      { status: 502 }
    );
  }
}
