import { NextRequest, NextResponse } from "next/server";
import { fetchDetail, slugFromUrl } from "@/lib/moviebox";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function POST(req: NextRequest) {
  let body: { url?: string } = {};
  try {
    body = await req.json();
  } catch {
    /* empty body */
  }
  const url = (body.url || "").trim();
  const slug = slugFromUrl(url);
  if (!slug) {
    return NextResponse.json(
      {
        ok: false,
        error:
          "Please paste a MovieBox link (themoviebox.xyz/detail/...) or search by name.",
      },
      { status: 400 }
    );
  }
  try {
    const detail = await fetchDetail(slug);
    return NextResponse.json(detail);
  } catch (e) {
    return NextResponse.json(
      { ok: false, error: e instanceof Error ? e.message : String(e) },
      { status: 502 }
    );
  }
}
