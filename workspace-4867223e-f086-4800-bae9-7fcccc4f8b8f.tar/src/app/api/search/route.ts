import { NextRequest, NextResponse } from "next/server";
import { searchMovieBox } from "@/lib/moviebox";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function POST(req: NextRequest) {
  let body: { q?: string; page?: number; perPage?: number } = {};
  try {
    body = await req.json();
  } catch {
    /* empty */
  }
  const q = (body.q || "").trim();
  if (!q) {
    return NextResponse.json({ ok: false, error: "empty query" }, { status: 400 });
  }
  try {
    const items = await searchMovieBox(q, body.page || 1, body.perPage || 24);
    return NextResponse.json({ ok: true, items });
  } catch (e) {
    return NextResponse.json(
      { ok: false, error: e instanceof Error ? e.message : String(e) },
      { status: 502 }
    );
  }
}
