import MovieBoxApp from "@/components/moviebox/app";

export default function Home() {
  return <MovieBoxApp />;
}
