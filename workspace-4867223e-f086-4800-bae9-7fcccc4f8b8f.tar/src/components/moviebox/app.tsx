"use client";

import {
  useCallback,
  useEffect,
  useMemo,
  useRef,
  useState,
} from "react";
import type {
  CaptionItem,
  DetailData,
  SearchResult,
  StreamItem,
} from "@/lib/moviebox";

/* ============================================================
   Types
   ============================================================ */
type Screen = "home" | "detail" | "downloads";

interface LinksResp {
  streams: StreamItem[];
  captions: CaptionItem[];
}

interface HistoryItem {
  filename: string;
  size: string;
  quality: string;
  title: string;
  url: string;
  ts: number;
  detailPath: string;
  subjectId: string;
  se: number;
  ep: number;
}

/* ============================================================
   Icon — Material Symbols Rounded (self-hosted font)
   ============================================================ */
function Icon({
  name,
  fill,
  className,
  style,
}: {
  name: string;
  fill?: boolean;
  className?: string;
  style?: React.CSSProperties;
}) {
  return (
    <span
      aria-hidden="true"
      className={`material-symbols-rounded${fill ? " fill" : ""}${className ? " " + className : ""}`}
      style={style}
    >
      {name}
    </span>
  );
}

/* ============================================================
   Helpers
   ============================================================ */
function epKey(se: number, ep: number) {
  return `${se}:${ep}`;
}

function pad2(n: number) {
  return String(n).padStart(2, "0");
}

function safeName(title: string | undefined) {
  return (title || "video")
    .replace(/[\\/:*?"<>|]+/g, "")
    .replace(/\s+/g, " ")
    .trim()
    .slice(0, 80);
}

function fmtBytes(n: number) {
  if (!n) return "0 B";
  const u = ["B", "KB", "MB", "GB"];
  let i = 0;
  let v = n;
  while (v >= 1024 && i < 3) {
    v /= 1024;
    i++;
  }
  return `${v.toFixed(i ? 1 : 0)} ${u[i]}`;
}

function sleep(ms: number) {
  return new Promise((r) => setTimeout(r, ms));
}

async function api<T = Record<string, unknown>>(
  path: string,
  body?: unknown
): Promise<T> {
  const opts: RequestInit = body
    ? {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
      }
    : {};
  const r = await fetch(path, opts);
  const d = await r.json().catch(() => ({ ok: false, error: "Bad server response" }));
  if (!r.ok && d && typeof d === "object" && "error" in d && d.error) {
    throw new Error(String(d.error));
  }
  if (
    d &&
    typeof d === "object" &&
    "ok" in d &&
    (d as { ok?: boolean }).ok === false &&
    "error" in d
  ) {
    throw new Error(String((d as { error?: string }).error));
  }
  return d as T;
}

function pickStream(links: LinksResp, quality: string | null): StreamItem | null {
  const streams = links.streams;
  if (!streams.length) return null;
  let st = streams.find((s) => s.resolution === quality);
  if (!st) {
    const quals = streams.map((s) => parseInt(s.resolution) || 0);
    const target = parseInt(quality || "") || 99999;
    let best = 0;
    for (let i = 1; i < streams.length; i++) {
      if (Math.abs(quals[i] - target) < Math.abs(quals[best] - target)) best = i;
    }
    st = streams[best];
  }
  return st;
}

function triggerBrowserDownload(url: string, filename: string) {
  const a = document.createElement("a");
  a.href = `/api/download?url=${encodeURIComponent(url)}&filename=${encodeURIComponent(filename)}`;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
}

/* ============================================================
   Main app
   ============================================================ */
export default function MovieBoxApp() {
  /* ---------- state ---------- */
  const [screen, setScreen] = useState<Screen>("home");
  const [query, setQuery] = useState("");
  const [loading, setLoading] = useState<{ on: boolean; msg: string }>({
    on: false,
    msg: "",
  });
  const [homeError, setHomeError] = useState<string | null>(null);
  const [results, setResults] = useState<SearchResult[] | null>(null);
  const [detail, setDetail] = useState<DetailData | null>(null);
  const [currentSe, setCurrentSe] = useState(0);
  const [selectedEps, setSelectedEps] = useState<Set<string>>(new Set());
  const [selectedQuality, setSelectedQuality] = useState<string | null>(null);
  const [selectedSubs, setSelectedSubs] = useState<Set<string>>(new Set());
  const [activeLinks, setActiveLinks] = useState<LinksResp | null>(null);
  const [downloading, setDownloading] = useState<Set<string>>(new Set());
  const [batchProgress, setBatchProgress] = useState<{
    done: number;
    total: number;
  } | null>(null);
  const [history, setHistory] = useState<HistoryItem[]>([]);
  const [snack, setSnack] = useState<{ text: string; id: number } | null>(null);

  /* ---------- refs ---------- */
  const linksCache = useRef(new Map<string, LinksResp>());
  const snackTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const screenRef = useRef<HTMLElement | null>(null);
  const detailRef = useRef<DetailData | null>(null);
  const qualityRef = useRef<string | null>(null);
  const subsRef = useRef<Set<string>>(new Set());
  const historyRef = useRef<HistoryItem[]>([]);

  useEffect(() => {
    detailRef.current = detail;
    qualityRef.current = selectedQuality;
    subsRef.current = selectedSubs;
    historyRef.current = history;
  });

  /* ---------- mount: history + ripple ---------- */
  useEffect(() => {
    try {
      const raw = localStorage.getItem("mb_dl_history");
      if (raw) setHistory(JSON.parse(raw));
    } catch {
      /* ignore */
    }
    const handler = (e: PointerEvent) => {
      const target = e.target as Element | null;
      const host = target?.closest?.(
        ".m3-chip, .btn-filled, .btn-tonal, .btn-text, .ep-dl, .result-card, .ep-card, .nav-item, .icon-btn"
      ) as HTMLElement | null;
      if (!host) return;
      const rect = host.getBoundingClientRect();
      const ink = document.createElement("span");
      ink.className = "ripple-ink";
      const size = Math.max(rect.width, rect.height);
      ink.style.width = ink.style.height = `${size}px`;
      ink.style.left = `${e.clientX - rect.left - size / 2}px`;
      ink.style.top = `${e.clientY - rect.top - size / 2}px`;
      if (getComputedStyle(host).position === "static") {
        host.style.position = "relative";
      }
      host.appendChild(ink);
      setTimeout(() => ink.remove(), 600);
    };
    document.addEventListener("pointerdown", handler);
    return () => document.removeEventListener("pointerdown", handler);
  }, []);

  useEffect(() => {
    try {
      localStorage.setItem("mb_dl_history", JSON.stringify(history));
    } catch {
      /* ignore */
    }
  }, [history]);

  /* ---------- snackbar ---------- */
  const showSnackbar = useCallback((msg: string, ms = 3200) => {
    setSnack({ text: msg, id: Date.now() });
    if (snackTimer.current) clearTimeout(snackTimer.current);
    snackTimer.current = setTimeout(() => setSnack(null), ms);
  }, []);

  /* ---------- navigation ---------- */
  const navigate = useCallback((s: Screen) => {
    setScreen(s);
    requestAnimationFrame(() => screenRef.current?.scrollTo({ top: 0 }));
  }, []);

  /* ---------- links fetching ---------- */
  const getLinks = useCallback(
    async (se: number, ep: number): Promise<LinksResp> => {
      const key = epKey(se, ep);
      const cached = linksCache.current.get(key);
      if (cached) return cached;
      const d = await api<{ ok: boolean; streams: StreamItem[]; captions: CaptionItem[] }>(
        "/api/links",
        {
          detailPath: detailRef.current?.detailPath,
          subjectId: detailRef.current?.subjectId,
          se: Number(se),
          ep: Number(ep),
        }
      );
      if (!d.streams || !d.streams.length) {
        throw new Error("No downloadable streams for this item");
      }
      const links = { streams: d.streams, captions: d.captions || [] };
      linksCache.current.set(key, links);
      return links;
    },
    []
  );

  const prefetchLinks = useCallback(
    async (se: number, ep: number) => {
      try {
        const links = await getLinks(se, ep);
        setActiveLinks(links);
        const quals = links.streams.map((s) => s.resolution);
        if (!qualityRef.current || !quals.includes(qualityRef.current)) {
          setSelectedQuality(quals[quals.length - 1] ?? null);
        }
      } catch {
        /* ignore prefetch failures */
      }
    },
    [getLinks]
  );

  /* ---------- render detail ---------- */
  const renderDetail = useCallback(
    (d: DetailData) => {
      setDetail(d);
      detailRef.current = d;
      setSelectedEps(new Set());
      setSelectedQuality(null);
      qualityRef.current = null;
      setSelectedSubs(new Set());
      linksCache.current = new Map();
      setActiveLinks(null);
      setScreen("detail");
      requestAnimationFrame(() => screenRef.current?.scrollTo({ top: 0 }));
      const content = d.content;
      if (content.layout === "episodes" && content.seasons?.length) {
        const se = content.seasons[0].se;
        setCurrentSe(se);
        void prefetchLinks(se, 1);
      } else if (content.items?.length) {
        const p0 = content.items[0];
        setCurrentSe(p0.se);
        void prefetchLinks(p0.se, p0.ep);
      }
    },
    [prefetchLinks]
  );

  /* ---------- search / resolve ---------- */
  const handleSearch = useCallback(async () => {
    const q = query.trim();
    if (!q) {
      showSnackbar("Paste a MovieBox link or type a name first");
      return;
    }
    setHomeError(null);
    setResults(null);
    const isUrl =
      /^(https?:\/\/|www\.|[a-z0-9-]+\.[a-z]{2,})/i.test(q) || /^[\w-]{15,}$/.test(q);
    if (isUrl) {
      setLoading({ on: true, msg: "Resolving link…" });
      try {
        const d = await api<DetailData>("/api/resolve", { url: q });
        setLoading({ on: false, msg: "" });
        renderDetail(d);
      } catch (err) {
        setLoading({ on: false, msg: "" });
        setHomeError(err instanceof Error ? err.message : String(err));
      }
    } else {
      setLoading({ on: true, msg: "Searching…" });
      try {
        const d = await api<{ ok: boolean; items: SearchResult[] }>("/api/search", {
          q,
        });
        setLoading({ on: false, msg: "" });
        setResults(d.items || []);
      } catch (err) {
        setLoading({ on: false, msg: "" });
        setHomeError(err instanceof Error ? err.message : String(err));
      }
    }
  }, [query, renderDetail, showSnackbar]);

  const openDetail = useCallback(
    async (slug: string) => {
      setLoading({ on: true, msg: "Loading…" });
      try {
        const d = await api<DetailData>(
          `/api/detail/${encodeURIComponent(slug)}`
        );
        setLoading({ on: false, msg: "" });
        renderDetail(d);
      } catch (err) {
        setLoading({ on: false, msg: "" });
        setHomeError(err instanceof Error ? err.message : String(err));
      }
    },
    [renderDetail]
  );

  const switchDub = useCallback(
    async (detailPath: string, lanName: string) => {
      showSnackbar(`Switching to ${lanName}…`);
      try {
        const d = await api<DetailData>(
          `/api/detail/${encodeURIComponent(detailPath)}`
        );
        renderDetail(d);
        showSnackbar(`Now showing: ${d.title}`);
      } catch (err) {
        showSnackbar(err instanceof Error ? err.message : String(err));
      }
    },
    [renderDetail, showSnackbar]
  );

  /* ---------- season / selection ---------- */
  const renderSeason = useCallback(
    (se: number) => {
      setCurrentSe(se);
      setSelectedEps(new Set());
      void prefetchLinks(se, 1);
    },
    [prefetchLinks]
  );

  const toggleEpisode = useCallback((se: number, ep: number) => {
    const key = epKey(se, ep);
    setSelectedEps((prev) => {
      const next = new Set(prev);
      if (next.has(key)) next.delete(key);
      else next.add(key);
      return next;
    });
  }, []);

  /* ---------- download flow ---------- */
  const buildFilename = useCallback(
    (se: number, ep: number, stream: StreamItem | null, ext = "mp4"): string => {
      const d = detailRef.current;
      const t = safeName(d?.title);
      const q = stream ? `${stream.resolution}p` : "";
      if (d?.type === "series" && d.content.layout === "episodes") {
        return `${t} - S${pad2(se)}E${pad2(ep)}${q ? " [" + q + "]" : ""}.${ext}`;
      }
      let label = "Movie";
      const content = d?.content;
      if (content?.layout === "parts" && content.items) {
        const p = content.items.find(
          (x) => x.se === Number(se) && x.ep === Number(ep)
        );
        if (p && content.items.length > 1) label = p.label;
      }
      return `${t}${label !== "Movie" ? " - " + label : ""}${q ? " [" + q + "]" : ""}.${ext}`;
    },
    []
  );

  const recordDownload = useCallback(
    (filename: string, stream: StreamItem, se: number, ep: number) => {
      const d = detailRef.current;
      setHistory((prev) =>
        [
          {
            filename,
            size: stream.size,
            quality: `${stream.resolution}p`,
            title: d?.title || "",
            url: stream.url,
            ts: Date.now(),
            detailPath: d?.detailPath || "",
            subjectId: d?.subjectId || "",
            se,
            ep,
          },
          ...prev,
        ].slice(0, 100)
      );
    },
    []
  );

  const downloadSubs = useCallback(
    async (se: number, ep: number, links: LinksResp) => {
      const subs = subsRef.current;
      if (!subs.size) return;
      const caps = (links.captions || []).filter((c) => subs.has(c.lanName));
      for (const c of caps) {
        const fname = buildFilename(se, ep, null, "srt").replace(
          /\.srt$/,
          ` [${c.lanName}].srt`
        );
        triggerBrowserDownload(c.url, fname);
        await sleep(400);
      }
    },
    [buildFilename]
  );

  const downloadOne = useCallback(
    async (se: number, ep: number) => {
      const key = epKey(se, ep);
      setDownloading((prev) => new Set(prev).add(key));
      try {
        // always fetch fresh links (CDN signs expire)
        linksCache.current.delete(key);
        const links = await getLinks(se, ep);
        setActiveLinks(links);
        const stream = pickStream(links, qualityRef.current);
        if (!stream) throw new Error("No stream available");
        const fname = buildFilename(se, ep, stream, "mp4");
        triggerBrowserDownload(stream.url, fname);
        recordDownload(fname, stream, se, ep);
        showSnackbar(`Downloading ${fname} — check your browser downloads`, 4000);
        await downloadSubs(se, ep, links);
      } catch (err) {
        showSnackbar(err instanceof Error ? err.message : String(err));
      } finally {
        setDownloading((prev) => {
          const next = new Set(prev);
          next.delete(key);
          return next;
        });
      }
    },
    [buildFilename, downloadSubs, getLinks, recordDownload, showSnackbar]
  );

  const runBatch = useCallback(async () => {
    const keys = [...selectedEps];
    if (!keys.length) return;
    setBatchProgress({ done: 0, total: keys.length });
    showSnackbar(
      `Starting ${keys.length} download${keys.length > 1 ? "s" : ""}… Your browser may ask to allow multiple files.`
    );
    let done = 0;
    for (const key of keys) {
      const [se, ep] = key.split(":").map(Number);
      try {
        await downloadOne(se, ep);
        done++;
        setBatchProgress({ done, total: keys.length });
      } catch (err) {
        console.error(err);
      }
      if (done < keys.length) await sleep(1600); // gentle on the CDN
    }
    setBatchProgress(null);
    if (done) {
      showSnackbar(
        `Started ${done} download${done > 1 ? "s" : ""} — watch the browser download bar`
      );
    }
  }, [downloadOne, selectedEps, showSnackbar]);

  const reDownload = useCallback(
    async (it: HistoryItem) => {
      try {
        // fetch a fresh signed link before re-downloading
        const d = await api<{ ok: boolean; streams: StreamItem[] }>("/api/links", {
          detailPath: it.detailPath,
          subjectId: it.subjectId,
          se: it.se,
          ep: it.ep,
        });
        const st =
          d.streams.find((s) => `${s.resolution}p` === it.quality) || d.streams[0];
        if (!st) throw new Error("No stream");
        triggerBrowserDownload(st.url, it.filename);
        showSnackbar(`Re-downloading ${it.filename}`);
      } catch (err) {
        if (it.url) {
          triggerBrowserDownload(it.url, it.filename);
          showSnackbar("Using cached link — if it fails, open the title again");
        } else {
          showSnackbar(err instanceof Error ? err.message : String(err));
        }
      }
    },
    [showSnackbar]
  );

  /* ---------- clipboard paste ---------- */
  const pasteClipboard = useCallback(async () => {
    try {
      const text = await navigator.clipboard.readText();
      if (text) setQuery(text.trim());
    } catch {
      showSnackbar("Clipboard not available — long-press to paste");
    }
  }, [showSnackbar]);

  /* ---------- subtitle toggle ---------- */
  const toggleSub = useCallback((lanName: string) => {
    setSelectedSubs((prev) => {
      const next = new Set(prev);
      if (next.has(lanName)) next.delete(lanName);
      else next.add(lanName);
      return next;
    });
  }, []);

  /* ---------- derived data ---------- */
  const d = detail;
  const content = d?.content;
  const isSeries = content?.layout === "episodes";
  const seasons = isSeries ? content?.seasons ?? [] : [];
  const currentSeason =
    seasons.find((s) => s.se === currentSe) || seasons[0] || null;
  const parts = !isSeries ? content?.items ?? [] : [];

  const cards = useMemo(() => {
    if (isSeries && currentSeason) {
      const arr: Array<{
        se: number;
        ep: number;
        label: string;
        sub: string;
      }> = [];
      const n = currentSeason.maxEp || 1;
      for (let ep = 1; ep <= n; ep++) {
        arr.push({
          se: currentSeason.se,
          ep,
          label: `Episode ${ep}`,
          sub: `S${pad2(currentSeason.se)} · EP${pad2(ep)} · tap to select`,
        });
      }
      return arr;
    }
    return parts.map((p) => ({
      se: p.se,
      ep: p.ep,
      label: p.label,
      sub: p.resolutions.length
        ? p.resolutions.map((r) => `${r}p`).join(" · ")
        : "tap download to see sizes",
    }));
  }, [isSeries, currentSeason, parts]);

  const allSelected = cards.length > 0 && selectedEps.size === cards.length;

  const selectAll = useCallback(() => {
    setSelectedEps((prev) => {
      if (prev.size === cards.length && cards.length > 0) return new Set();
      return new Set(cards.map((c) => epKey(c.se, c.ep)));
    });
  }, [cards]);

  /* batch size estimate (from links cache) */
  let batchBytes = 0;
  let batchKnown = 0;
  for (const key of selectedEps) {
    const links = linksCache.current.get(key);
    if (links) {
      const st = pickStream(links, selectedQuality);
      if (st) {
        batchBytes += st.sizeBytes;
        batchKnown++;
      }
    }
  }

  const navActive = screen === "detail" ? "home" : screen;

  /* ============================================================
     Render
     ============================================================ */
  return (
    <div className="phone-frame">
      {/* ============ TOP APP BAR ============ */}
      <header className={`top-bar${screen === "detail" ? " elevated" : ""}`}>
        <div className="top-bar-row">
          {screen === "detail" && (
            <button
              className="icon-btn"
              aria-label="Back"
              onClick={() => navigate("home")}
            >
              <Icon name="arrow_back" />
            </button>
          )}
          <div className="app-brand">
            <Icon name="movie" className="brand-icon" />
            <span className="brand-name">MovieBox</span>
          </div>
          {screen === "detail" && <span className="top-title">{d?.title}</span>}
        </div>
      </header>

      {/* ============ HOME / SEARCH SCREEN ============ */}
      {screen === "home" && (
        <main className="screen" ref={screenRef}>
          <div className="home-hero">
            <div className="hero-emoji">
              <Icon name="download_for_offline" />
            </div>
            <h1>Download movies &amp; dramas</h1>
            <p className="hero-sub">Paste a MovieBox link or search by name</p>
          </div>

          <div className="search-wrap">
            <div className="search-bar">
              <Icon name="search" />
              <input
                type="url"
                placeholder="Paste link or search…"
                autoComplete="off"
                spellCheck={false}
                aria-label="Paste a MovieBox link or search by name"
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === "Enter") void handleSearch();
                }}
              />
              {query && (
                <button
                  className="icon-btn"
                  aria-label="Clear"
                  onClick={() => setQuery("")}
                >
                  <Icon name="close" />
                </button>
              )}
              <button
                className="icon-btn"
                aria-label="Paste from clipboard"
                onClick={() => void pasteClipboard()}
              >
                <Icon name="content_paste" />
              </button>
            </div>
            <button
              className="btn-filled search-go"
              onClick={() => void handleSearch()}
              disabled={loading.on}
            >
              Go
            </button>
          </div>

          <div className="hint-card">
            <div className="hint-row">
              <Icon name="link" />
              <span>
                Paste a link like <code>themoviebox.xyz/detail/…</code>
              </span>
            </div>
            <div className="hint-row">
              <Icon name="search" />
              <span>Or type a movie / drama name</span>
            </div>
          </div>

          {loading.on && (
            <div className="loading-block">
              <div className="spinner" />
              <span>{loading.msg}</span>
            </div>
          )}

          {homeError && <div className="empty-msg">{homeError}</div>}

          {results && (
            <section aria-label="Search results">
              <h2 className="section-title">Results</h2>
              <div className="result-grid">
                {results.length === 0 && (
                  <div className="no-res">
                    No results found — try another name
                  </div>
                )}
                {results.map((it) => (
                  <button
                    key={it.detailPath || it.title}
                    className="result-card"
                    onClick={() => void openDetail(it.detailPath)}
                  >
                    <img
                      src={it.cover || undefined}
                      alt={it.title}
                      loading="lazy"
                      onError={(e) => {
                        (e.currentTarget as HTMLImageElement).style.visibility =
                          "hidden";
                      }}
                    />
                    <div className="result-info">
                      <div className="result-title">{it.title}</div>
                      <div className="result-meta">
                        <span className={`tag-badge ${it.type}`}>{it.type}</span>
                        {it.year && (
                          <span className="result-year">{it.year}</span>
                        )}
                        {!it.hasResource && (
                          <span className="result-year">· no download</span>
                        )}
                      </div>
                    </div>
                  </button>
                ))}
              </div>
            </section>
          )}
        </main>
      )}

      {/* ============ DETAIL SCREEN ============ */}
      {screen === "detail" && d && (
        <main className="screen" ref={screenRef}>
          <div className="detail-hero">
            <img
              src={d.cover || undefined}
              alt={d.title}
              onError={(e) => {
                (e.currentTarget as HTMLImageElement).style.visibility =
                  "hidden";
              }}
            />
            <div className="hero-scrim" />
            <div className="hero-info">
              <span className="type-badge">
                {d.type === "series" ? "TV Series" : d.type === "movie" ? "Movie" : "Video"}
              </span>
              <h1>{d.title}</h1>
              <div className="meta-row">
                {d.year && (
                  <span className="meta-chip">
                    <Icon name="calendar_month" />
                    {d.year}
                  </span>
                )}
                {d.country && (
                  <span className="meta-chip">
                    <Icon name="public" />
                    {d.country}
                  </span>
                )}
                {d.duration && (
                  <span className="meta-chip">
                    <Icon name="schedule" />
                    {d.duration}
                  </span>
                )}
                {d.imdb && d.imdb !== "0" && (
                  <span className="meta-chip">
                    <Icon name="star" fill className="star" />
                    IMDb {d.imdb}
                  </span>
                )}
                {d.genres.slice(0, 3).map((g) => (
                  <span key={g} className="meta-chip">
                    {g}
                  </span>
                ))}
              </div>
            </div>
          </div>

          <div className="detail-body">
            {/* description + cast */}
            <div className="desc-card">
              <p>{d.description || "No description available."}</p>
              {d.cast.length > 0 && (
                <div className="cast-row">
                  {d.cast.slice(0, 10).map((c) => (
                    <div key={c.name} className="cast-pill">
                      {c.avatar && (
                        <img src={c.avatar} alt={c.name} loading="lazy" />
                      )}
                      <span className="cast-name">{c.name}</span>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* dub languages */}
            {d.dubs.length > 1 && (
              <div className="chip-block">
                <h3 className="chip-title">
                  <Icon name="translate" /> Audio / Dub language
                </h3>
                <div className="chip-row">
                  {d.dubs.map((dub) => (
                    <button
                      key={dub.detailPath + dub.lanName}
                      className={`m3-chip${dub.current ? " selected" : ""}`}
                      disabled={dub.current}
                      onClick={() => void switchDub(dub.detailPath, dub.lanName)}
                    >
                      <Icon name={dub.original ? "graphic_eq" : "translate"} />
                      {dub.lanName}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* seasons */}
            {isSeries && seasons.length > 0 && (
              <div className="chip-block">
                <h3 className="chip-title">
                  <Icon name="tv" /> Season
                </h3>
                <div className="chip-row">
                  {seasons.map((s) => (
                    <button
                      key={s.se}
                      className={`m3-chip${s.se === currentSe ? " selected" : ""}`}
                      onClick={() => renderSeason(s.se)}
                    >
                      <Icon name="tv" />
                      {s.label.replace("Season ", "S")}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* quality */}
            {activeLinks && activeLinks.streams.length > 0 && (
              <div className="chip-block">
                <h3 className="chip-title">
                  <Icon name="high_quality" /> Quality
                </h3>
                <div className="chip-row">
                  {activeLinks.streams.map((s) => (
                    <button
                      key={`${s.resolution}-${s.id}`}
                      className={`m3-chip${s.resolution === selectedQuality ? " selected" : ""}`}
                      onClick={() => setSelectedQuality(s.resolution)}
                    >
                      <Icon name="high_quality" />
                      {s.resolution}p · {s.size}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* subtitles */}
            {activeLinks && activeLinks.captions.length > 0 && (
              <div className="chip-block">
                <h3 className="chip-title">
                  <Icon name="subtitles" /> Subtitles (saved with video)
                </h3>
                <div className="chip-row">
                  {activeLinks.captions.map((c) => (
                    <button
                      key={c.lanName + c.url}
                      className={`m3-chip${selectedSubs.has(c.lanName) ? " selected" : ""}`}
                      onClick={() => toggleSub(c.lanName)}
                    >
                      <Icon name="subtitles" />
                      {c.lanName}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* episode / part list */}
            <section aria-label={isSeries ? "Episodes" : "Movie"}>
              <div className="list-head">
                <h2 className="section-title">{isSeries ? "Episodes" : "Movie"}</h2>
                {cards.length > 1 && (
                  <button className="btn-text" onClick={selectAll}>
                    <Icon name="select_all" />
                    {allSelected ? "Deselect all" : "Select all"}
                  </button>
                )}
              </div>
              <div className="ep-list">
                {cards.map((card) => {
                  const key = epKey(card.se, card.ep);
                  const isSel = selectedEps.has(key);
                  const isDl = downloading.has(key);
                  return (
                    <div
                      key={key}
                      className={`ep-card${isSel ? " selected" : ""}`}
                      role="button"
                      tabIndex={0}
                      aria-pressed={isSel}
                      onClick={() => toggleEpisode(card.se, card.ep)}
                      onKeyDown={(e) => {
                        if (e.key === " " || e.key === "Enter") {
                          e.preventDefault();
                          toggleEpisode(card.se, card.ep);
                        }
                      }}
                    >
                      <span className="ep-check">
                        <Icon name="check" />
                      </span>
                      <div className="ep-info">
                        <div className="ep-name">{card.label}</div>
                        <div className="ep-sub">{card.sub}</div>
                      </div>
                      <button
                        className="ep-dl"
                        title="Download"
                        aria-label={`Download ${card.label}`}
                        disabled={isDl}
                        onClick={(e) => {
                          e.stopPropagation();
                          void downloadOne(card.se, card.ep);
                        }}
                      >
                        <Icon name={isDl ? "hourglass_top" : "download"} />
                      </button>
                    </div>
                  );
                })}
              </div>
            </section>
          </div>
        </main>
      )}

      {/* ============ DOWNLOADS SCREEN ============ */}
      {screen === "downloads" && (
        <main className="screen" ref={screenRef}>
          <h2 className="screen-title">Downloads</h2>
          <p className="screen-sub">
            Files save to your browser&apos;s download folder. History is stored
            on this device only.
          </p>
          <div className="dl-list">
            {history.length === 0 && (
              <div className="empty-msg">Nothing downloaded yet</div>
            )}
            {history.map((it) => {
              const when = new Date(it.ts).toLocaleString([], {
                month: "short",
                day: "numeric",
                hour: "2-digit",
                minute: "2-digit",
              });
              return (
                <div key={`${it.ts}-${it.filename}`} className="dl-card">
                  <div className="dl-icon">
                    <Icon name="movie" />
                  </div>
                  <div className="dl-info">
                    <div className="dl-title">{it.filename}</div>
                    <div className="dl-meta">
                      {it.quality} · {it.size} · {when}
                    </div>
                  </div>
                  <button
                    className="dl-again"
                    title="Download again"
                    aria-label={`Download ${it.filename} again`}
                    onClick={() => void reDownload(it)}
                  >
                    <Icon name="refresh" />
                  </button>
                </div>
              );
            })}
          </div>
          {history.length > 0 && (
            <button
              className="btn-tonal clear-history"
              onClick={() => {
                setHistory([]);
                try {
                  localStorage.removeItem("mb_dl_history");
                } catch {
                  /* ignore */
                }
                showSnackbar("History cleared (your files are untouched)");
              }}
            >
              <Icon name="delete" /> Clear history
            </button>
          )}
        </main>
      )}

      {/* ============ BATCH DOWNLOAD BAR ============ */}
      {screen === "detail" && selectedEps.size > 0 && (
        <div className="batch-bar" role="status">
          <div className="batch-info">
            <span className="batch-count">
              {batchProgress
                ? `${batchProgress.done}/${batchProgress.total} started`
                : `${selectedEps.size} selected`}
            </span>
            {batchKnown > 0 && (
              <span className="batch-size">
                ~{fmtBytes(batchBytes)} total (estimated
                {batchKnown < selectedEps.size ? ", loading…" : ""})
              </span>
            )}
          </div>
          <button
            className="btn-filled btn-download"
            onClick={() => void runBatch()}
            disabled={!!batchProgress}
          >
            <Icon name="download" /> Download
          </button>
        </div>
      )}

      {/* ============ BOTTOM NAV (Android style) ============ */}
      <nav className="bottom-nav" aria-label="Main navigation">
        <button
          className={`nav-item${navActive === "home" ? " active" : ""}`}
          onClick={() => navigate("home")}
        >
          <span className="nav-pill" />
          <Icon name="home" />
          <span className="nav-label">Home</span>
        </button>
        <button
          className={`nav-item${navActive === "downloads" ? " active" : ""}`}
          onClick={() => navigate("downloads")}
        >
          <span className="nav-pill" />
          <Icon name="download" />
          <span className="nav-label">Downloads</span>
        </button>
      </nav>

      {/* ============ SNACKBAR ============ */}
      <div className={`snackbar${snack ? " show" : ""}`} role="status">
        <span>{snack?.text}</span>
      </div>
    </div>
  );
}
