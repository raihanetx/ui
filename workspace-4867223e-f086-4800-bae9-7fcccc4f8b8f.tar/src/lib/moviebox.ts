/**
 * MovieBox backend library
 * Reverse-engineered API client for themoviebox.xyz (guest access, no login).
 */

export const API_BASE = "https://h5-api.aoneroom.com/wefeed-h5api-bff";
export const PLAY_BASE = "https://themoviebox.xyz/wefeed-h5api-bff";
export const SITE_ORIGIN = "https://themoviebox.xyz";

export const MOBILE_UA =
  "Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36";

/* ------------------------------------------------------------------ */
/* Types                                                              */
/* ------------------------------------------------------------------ */
export interface Dub {
  lanName: string;
  lanCode: string;
  detailPath: string;
  original: boolean;
  current: boolean;
}

export interface PartItem {
  se: number;
  ep: number;
  label: string;
  resolutions: number[];
}

export interface SeasonItem {
  se: number;
  maxEp: number;
  label: string;
  resolutions: number[];
}

export interface ContentLayout {
  layout: "parts" | "episodes";
  items?: PartItem[];
  seasons?: SeasonItem[];
}

export interface CastMember {
  name: string;
  character: string;
  avatar: string;
}

export interface DetailData {
  ok: boolean;
  subjectId: string;
  detailPath: string;
  type: string;
  title: string;
  description: string;
  cover: string;
  releaseDate: string;
  year: string;
  duration: string;
  durationSeconds: number;
  genres: string[];
  country: string;
  imdb: string;
  source: string;
  dubs: Dub[];
  subtitles: string[];
  cast: CastMember[];
  content: ContentLayout;
  hasResource: boolean;
}

export interface StreamItem {
  format: string;
  id: string;
  url: string;
  resolution: string;
  size: string;
  sizeBytes: number;
  duration: string;
}

export interface CaptionItem {
  lanName: string;
  lan: string;
  url: string;
  size: string;
}

export interface SearchResult {
  title: string;
  detailPath: string;
  type: string;
  cover: string;
  year: string;
  hasResource: boolean;
}

/* ------------------------------------------------------------------ */
/* Guest token (anonymous, issued by the site itself)                 */
/* ------------------------------------------------------------------ */
interface TokenCache {
  token?: string;
  expiry?: number;
}

const g = globalThis as typeof globalThis & { __mbTokenCache?: TokenCache };
const cache: TokenCache = (g.__mbTokenCache ??= {});

export async function getGuestToken(): Promise<string> {
  const now = Date.now();
  if (cache.token && cache.expiry && now < cache.expiry - 3600_000) {
    return cache.token;
  }
  try {
    const r = await fetch(`${API_BASE}/country-code`, {
      headers: {
        "User-Agent": MOBILE_UA,
        Origin: SITE_ORIGIN,
        Referer: `${SITE_ORIGIN}/`,
      },
      signal: AbortSignal.timeout(20_000),
    });
    const setCookie = r.headers.get("set-cookie") || "";
    const m = /token=([^;]+)/.exec(setCookie);
    const token = m?.[1];
    if (!token) throw new Error("no guest token issued");
    cache.token = token;
    // refresh daily-ish
    cache.expiry = now + 6 * 24 * 3600 * 1000;
    return token;
  } catch (e) {
    if (cache.token) return cache.token; // fall back to old token
    throw new Error(`failed to get guest token: ${String(e)}`);
  }
}

export function apiHeaders(opts: {
  bearer?: boolean;
  referer?: string;
  json?: boolean;
} = {}): Record<string, string> {
  const h: Record<string, string> = {
    "User-Agent": MOBILE_UA,
    Origin: SITE_ORIGIN,
    Referer: opts.referer ?? `${SITE_ORIGIN}/`,
    "x-request-lang": "en",
  };
  if (opts.json) h["Content-Type"] = "application/json";
  if (opts.bearer !== false) {
    // callers that need bearer must pass the token (sync contexts use cached)
  }
  return h;
}

export async function authHeaders(
  opts: { referer?: string; json?: boolean } = {}
): Promise<Record<string, string>> {
  const token = await getGuestToken();
  return {
    ...apiHeaders({ referer: opts.referer, json: opts.json }),
    authorization: `Bearer ${token}`,
  };
}

/* ------------------------------------------------------------------ */
/* Helpers                                                            */
/* ------------------------------------------------------------------ */
export function slugFromUrl(input: string): string | null {
  if (!input) return null;
  let url = input.trim();
  if (!url.startsWith("http")) {
    if (/^[A-Za-z0-9_-]{4,}$/.test(url)) return url; // bare slug
    url = "https://" + url.replace(/^\/+/, "");
  }
  try {
    const p = new URL(url);
    // /detail/{slug} or /movies/{slug} (skip locale prefixes like /hi/)
    const m = /\/(?:detail|movies|video)(?:\/([^/]+))?\/([A-Za-z0-9_-]+)/.exec(p.pathname);
    if (m) return m[2];
    const m2 = /\/(?:detail|movies|video)\/([A-Za-z0-9_-]+)/.exec(p.pathname);
    if (m2) return m2[1];
    return null;
  } catch {
    return null;
  }
}

export function fmtSize(num: unknown): string {
  let n = Number(num);
  if (!Number.isFinite(n)) return "";
  const units = ["B", "KB", "MB", "GB"];
  let i = 0;
  while (n >= 1024 && i < 3) {
    n /= 1024;
    i++;
  }
  return `${i === 0 ? n.toFixed(0) : n.toFixed(1)} ${units[i]}`;
}

export function fmtDuration(sec: unknown): string {
  const s = Number(sec);
  if (!Number.isFinite(s) || s <= 0) return "";
  const h = Math.floor(s / 3600);
  const m = Math.floor((s % 3600) / 60);
  return h ? `${h}h ${String(m).padStart(2, "0")}m` : `${m}m`;
}

const TYPE_NAMES: Record<number, string> = { 1: "movie", 2: "series", 6: "video" };

/* ------------------------------------------------------------------ */
/* Detail normalization — auto content-type detection                 */
/* ------------------------------------------------------------------ */
interface RawSubject {
  subjectId?: string | number;
  subjectType?: number;
  title?: string;
  description?: string;
  releaseDate?: string;
  duration?: number;
  genre?: string;
  countryName?: string;
  imdbRatingValue?: number | string;
  detailPath?: string;
  cover?: { url?: string };
  subtitles?: string;
  dubs?: Array<{
    lanName?: string;
    lanCode?: string;
    detailPath?: string;
    original?: boolean | number;
  }>;
  hasResource?: boolean;
  isForbid?: boolean | number;
}

interface RawSeason {
  se?: number;
  maxEp?: number;
  resolutions?: Array<{ resolution?: number | string; epNum?: number }>;
}

export function normalizeDetail(data: Record<string, unknown>): DetailData {
  const subj = (data.subject || {}) as RawSubject;
  const resource = (data.resource || {}) as {
    seasons?: RawSeason[];
    source?: string;
  };
  const stars = (data.stars || []) as Array<{
    name?: string;
    character?: string;
    avatarUrl?: string;
  }>;

  const typeName = TYPE_NAMES[subj.subjectType ?? 0] ?? "video";

  const seasons: SeasonItem[] = [];
  const parts: PartItem[] = [];
  for (const s of resource.seasons || []) {
    const resolutions = Array.from(
      new Set(
        (s.resolutions || [])
          .map((r) => Number(r.resolution))
          .filter((r) => Number.isFinite(r) && r > 0)
      )
    ).sort((a, b) => a - b);
    seasons.push({
      se: s.se ?? 0,
      maxEp: s.maxEp ?? 0,
      label: `Season ${s.se ?? 0}`,
      resolutions,
    });
  }

  let content: ContentLayout;

  if (typeName === "movie" && seasons.length) {
    // movies: season entries without episodes = multi-part movie
    const allZero = seasons.every((s) => !s.maxEp);
    if (allZero && seasons.length > 0) {
      if (seasons.length === 1) {
        parts.push({ se: seasons[0].se, ep: 0, label: "Movie", resolutions: seasons[0].resolutions });
      } else {
        for (const s of seasons) {
          parts.push({
            se: s.se,
            ep: 0,
            label: s.se ? `Part ${s.se}` : "Movie",
            resolutions: s.resolutions,
          });
        }
      }
      content = { layout: "parts", items: parts };
    } else {
      // movie with episode-ish parts: show as one movie card
      const allRes = Array.from(
        new Set(seasons.flatMap((s) => s.resolutions))
      ).sort((a, b) => a - b);
      content = {
        layout: "parts",
        items: [{ se: 0, ep: 0, label: "Movie", resolutions: allRes }],
      };
    }
  } else if (seasons.length) {
    const eps: SeasonItem[] = seasons.map((s) => ({
      se: s.se,
      maxEp: s.maxEp && s.maxEp > 0 ? s.maxEp : 1,
      label: s.label,
      resolutions: s.resolutions,
    }));
    content = { layout: "episodes", seasons: eps };
  } else {
    content = {
      layout: "parts",
      items: [{ se: 0, ep: 0, label: typeName === "movie" ? "Movie" : "Video", resolutions: [] }],
    };
  }

  const subjPath = subj.detailPath || "";
  let dubs: Dub[] = (subj.dubs || []).map((d) => ({
    lanName: d.lanName || "",
    lanCode: d.lanCode || "",
    detailPath: d.detailPath || "",
    original: Boolean(d.original),
    current: (d.detailPath || "") === subjPath,
  }));
  if (!dubs.length) {
    dubs = [
      { lanName: "Original", lanCode: "", detailPath: subjPath, original: true, current: true },
    ];
  }

  const subtitles = String(subj.subtitles || "")
    .split(",")
    .map((x) => x.trim())
    .filter(Boolean);

  const cast: CastMember[] = (stars || []).slice(0, 12).map((s) => ({
    name: s.name || "",
    character: s.character || "",
    avatar: s.avatarUrl || "",
  }));

  const genres = String(subj.genre || "")
    .split(",")
    .map((x) => x.trim())
    .filter(Boolean);

  return {
    ok: true,
    subjectId: String(subj.subjectId || ""),
    detailPath: subjPath,
    type: typeName,
    title: subj.title || "",
    description: subj.description || "",
    cover: subj.cover?.url || "",
    releaseDate: subj.releaseDate || "",
    year: String(subj.releaseDate || "").slice(0, 4),
    duration: fmtDuration(subj.duration),
    durationSeconds: subj.duration || 0,
    genres,
    country: subj.countryName || "",
    imdb: String(subj.imdbRatingValue || ""),
    source: resource.source || "",
    dubs,
    subtitles,
    cast,
    content,
    hasResource: Boolean(subj.hasResource) || seasons.length > 0,
  };
}

/* ------------------------------------------------------------------ */
/* API wrappers                                                       */
/* ------------------------------------------------------------------ */
export async function fetchDetail(slug: string): Promise<DetailData> {
  const r = await fetch(
    `${API_BASE}/detail?detailPath=${encodeURIComponent(slug)}`,
    {
      headers: apiHeaders({ bearer: false }),
      signal: AbortSignal.timeout(25_000),
    }
  );
  const d = (await r.json()) as { code?: number; data?: Record<string, unknown>; message?: string };
  if (d.code !== 0 || !d.data) {
    throw new Error(d.message || "Not found on MovieBox. Check the link and try again.");
  }
  const data = d.data;
  if ((data as RawSubject).isForbid) {
    throw new Error("This title is blocked/restricted.");
  }
  return normalizeDetail(data);
}

export interface PlayResponse {
  streams: StreamItem[];
  captions: CaptionItem[];
}

export async function fetchLinks(
  detailPath: string,
  subjectId: string,
  se: number,
  ep: number
): Promise<PlayResponse> {
  const referer = `${SITE_ORIGIN}/movies/${detailPath}`;
  const params = new URLSearchParams({
    subjectId,
    se: String(se),
    ep: String(ep),
    detailPath,
    streamSignType: "1",
    "supportCodecs[h264]": "1",
  });
  const r = await fetch(`${PLAY_BASE}/subject/play?${params.toString()}`, {
    headers: await authHeaders({ referer }),
    signal: AbortSignal.timeout(30_000),
  });
  const d = (await r.json()) as {
    code?: number;
    message?: string;
    data?: {
      streams?: Array<{
        format?: string;
        id?: string;
        url?: string;
        resolutions?: string | number;
        size?: number;
        duration?: number;
        vipLocked?: boolean | number;
      }>;
    };
  };
  if (d.code !== 0) throw new Error(d.message || "play API error");

  const streams: StreamItem[] = [];
  for (const s of d.data?.streams || []) {
    if (s.vipLocked || !s.url) continue;
    streams.push({
      format: s.format || "MP4",
      id: s.id || "",
      url: s.url,
      resolution: String(s.resolutions ?? ""),
      size: fmtSize(s.size),
      sizeBytes: Number(s.size) || 0,
      duration: fmtDuration(s.duration),
    });
  }
  streams.sort((a, b) => (parseInt(a.resolution) || 0) - (parseInt(b.resolution) || 0));

  // captions from the first available stream
  const captions: CaptionItem[] = [];
  if (streams.length) {
    try {
      const cParams = new URLSearchParams({
        format: "MP4",
        id: streams[0].id,
        subjectId,
        detailPath,
      });
      const rc = await fetch(`${API_BASE}/subject/caption?${cParams.toString()}`, {
        headers: await authHeaders({ referer }),
        signal: AbortSignal.timeout(20_000),
      });
      const cd = (await rc.json()) as {
        data?: {
          captions?: Array<{
            lanName?: string;
            lan?: string;
            url?: string;
            size?: number;
          }>;
        };
      };
      for (const c of cd.data?.captions || []) {
        if (!c.url) continue;
        captions.push({
          lanName: c.lanName || "",
          lan: c.lan || "",
          url: c.url,
          size: fmtSize(c.size),
        });
      }
    } catch {
      /* subtitles optional */
    }
  }

  return { streams, captions };
}

export async function searchMovieBox(
  keyword: string,
  page = 1,
  perPage = 24
): Promise<SearchResult[]> {
  const r = await fetch(`${API_BASE}/subject/search`, {
    method: "POST",
    headers: await authHeaders({ json: true }),
    body: JSON.stringify({ keyword, page, perPage }),
    signal: AbortSignal.timeout(25_000),
  });
  const d = (await r.json()) as {
    data?: {
      items?: Array<{
        title?: string;
        detailPath?: string;
        subjectType?: number;
        cover?: { url?: string } | string;
        releaseDate?: string;
        hasResource?: boolean;
      }>;
    };
  };
  const items: SearchResult[] = [];
  for (const i of d.data?.items || []) {
    const cover =
      typeof i.cover === "object" && i.cover !== null ? i.cover.url || "" : i.cover || "";
    items.push({
      title: i.title || "",
      detailPath: i.detailPath || "",
      type: TYPE_NAMES[i.subjectType ?? 0] ?? "video",
      cover,
      year: String(i.releaseDate || "").slice(0, 4),
      hasResource: Boolean(i.hasResource),
    });
  }
  return items;
}
