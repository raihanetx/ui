# Worklog

---
Task ID: 1
Agent: Super Z (main agent)
Task: Reverse-engineer themoviebox.xyz API for video downloader tool

Work Log:
- Fetched detail page https://themoviebox.xyz/detail/teach-you-a-lesson-hindi-eFztro3UVh5 (Nuxt.js SPA)
- Extracted config from window.__NUXT__: API base = https://h5-api.aoneroom.com, path prefix /wefeed-h5api-bff
- Downloaded 30+ JS bundles, found endpoint builder functions
- Used agent-browser (headless Chrome) to trace runtime network calls on detail + player pages
- Verified all endpoints with curl

Stage Summary (COMPLETE API MAP):
1. GUEST TOKEN: GET https://h5-api.aoneroom.com/wefeed-h5api-bff/country-code
   -> Set-Cookie: token={JWT} (guest, valid ~90d, no login needed)
2. DETAIL: GET {API}/detail?detailPath={slug}
   -> subject{subjectId, subjectType(1=movie,2=series,6=song), title, description, releaseDate, duration(sec), genre, countryName, imdbRatingValue, cover{url}, subtitles(csv str), dubs[{lanName,lanCode,detailPath,original}], hasResource}
   -> resource{seasons[{se,maxEp,resolutions[{resolution,epNum}]}], source}
   -> stars[{name,character,avatarUrl,staffType}]
3. PLAY: GET https://themoviebox.xyz/wefeed-h5api-bff/subject/play?subjectId={id}&se={se}&ep={ep}&detailPath={slug}&streamSignType=1&supportCodecs[h264]=1
   REQUIRED: Authorization: Bearer {token} + Referer: https://themoviebox.xyz/... (else empty)
   -> streams[{format:MP4, id, url(CDN+sign), resolutions:"480", size, duration, vipLocked}]
   Movie: se=0&ep=0. Series: se=1..N, ep=1..maxEp
4. CAPTIONS: GET {API}/subject/caption?format=MP4&id={streamId}&subjectId={id}&detailPath={slug} (+Bearer)
   -> captions[{lanName, url(SRT signed), size, delay}]
5. SEARCH: POST {API}/subject/search {keyword,page,perPage} (+Bearer)
   -> items[{title,subjectType,detailPath,cover,releaseDate,hasResource}]
6. MP4 CDN URLs downloadable directly with GET; Range supported (HTTP 206 verified)
   - URL pattern from user: /detail/{slug}?id=...&type=/movie/detail ; also /movies/{slug} watch page
   - Dubs are separate subjects with own detailPath (language switch = refetch detail)
- Verified: 480/720/1080p MP4 links, 10+ subtitle languages, multi-season (Friends S1-S10), movie (Gadar 2), all with guest token

---
Task ID: 2
Agent: Super Z (main agent)
Task: Build MovieBox Downloader (Python Flask + Material 3 frontend)

Work Log:
- Built /home/z/my-project/download/moviebox-downloader/
  - app.py: Flask backend (guest token mgmt, resolve/detail/links/search APIs,
    streaming download proxy with Range + Content-Disposition)
  - static/index.html + style.css + app.js: Material 3 Android-style UI
    (phone frame, top app bar, small search bar, bottom nav with pill,
    chips for dub/season/quality/subtitles, episode cards with checkboxes,
    batch bar, download history in localStorage, ripple effects, dark mode)
- Fixed 405 bug: /api/detail route now accepts GET+POST
- Fixed select-all visibility for single movies
- E2E tests all passed:
  resolve(user URL) OK; links S1E1 480/720/1080 + English subs OK;
  download proxy HTTP 206 valid MP4 OK; search "gadar" 16 results OK;
  movie resolve OK (Gadar 2 parts layout); dub switch Hindi<->French OK;
  Friends S1-S10 10 season chips, 24 episode cards OK;
  batch download of 2 eps recorded in history OK;
  screenshots verified via VLM (Material 3 polished, Android-like)

Stage Summary:
- Deliverable: /home/z/my-project/download/moviebox-downloader.zip (445 KB)
- Run: pip install -r requirements.txt; python app.py; open localhost:8000
- All requested features implemented: auto content-type detection
  (movie/multi-part/series), cover, title, details, seasons, episodes,
  dub languages, qualities with sizes, subtitles, batch select + download
  via browser's native download manager, history

---
Task ID: 3
Agent: Super Z (main agent)
Task: Deploy MovieBox Downloader as live Next.js web app (user asked for
a website/webview to easily use the downloader without running Python)

Work Log:
- Initialized fullstack env (init-fullstack.sh), Next.js 16 dev server on :3000
- Self-hosted fonts: Material Symbols Rounded (5.4MB woff2) + Roboto 400/500/700
  in public/fonts/ (guaranteed Android look, no external font dependency)
- Ported Flask backend to TypeScript:
  - src/lib/moviebox.ts: token manager (globalThis cache), API wrappers,
    normalizeDetail (auto movie/series/multi-part detection), slug parser
  - API routes: /api/resolve, /api/detail/[slug], /api/links, /api/search,
    /api/download (streaming proxy, Range forwarding, Content-Disposition,
    host allowlist hakunaymatata/aoneroom/themoviebox, no timeout for big files)
- Ported Material 3 UI to React (src/components/moviebox/app.tsx ~1100 lines):
  phone frame, top app bar w/ back, small search bar + Go, paste button,
  hint card, results grid, detail hero (cover/scrim/badge/meta chips),
  description + cast pills, dub/season/quality/subtitle chips, episode cards
  with checkboxes + per-ep download, batch bar with size estimate + progress,
  bottom nav with active pill, snackbar, ripple effect, dark mode (auto),
  localStorage download history + re-download (fresh signed links)
- BUG FIXED: navigate useCallback was lost during file rewrite -> nav buttons
  threw ReferenceError (dev mode doesn't type-check). Restored; verified via
  agent-browser errors --json.
- ESLint: moved old investigation bundles out of lint scope (eslint.config.mjs
  ignores site-investigation/scripts/download); lint clean; tsc clean
- E2E verified with agent-browser (430x900 phone viewport):
  home renders (VLM: "high-fidelity Material 3") / resolve user URL -> detail
  (14 dub chips, S1, 480/720/1080 with sizes, English subs, 10 episodes) /
  search "friends" -> results -> Friends S10: 10 season chips, 24 eps, 3
  quality chips, 10 subtitle chips / season switch to S5 (S05 EP01) /
  episode select x2 + batch download -> E1 (1080p, 430MB) streamed in 38s,
  E2 recorded / Downloads history screen (2 items) / back button / dark mode
  (VLM ok) / desktop phone frame (VLM ok) / zero page errors
- Download proxy verified: HTTP 206 + Content-Range + Accept-Ranges + valid
  MP4 bytes (file: ISO Media MP4 v1)

Stage Summary:
- Live web app running on dev server port 3000 (user gets preview link;
  works on desktop + Android browsers)
- Same auto-detection features as Flask version, now hosted:
  paste link or search -> full detail -> pick dub/season/quality/subtitles ->
  batch download via browser's native download manager (pause/resume via Range)
- Offline alternative kept: download/moviebox-downloader.zip (Flask version)
